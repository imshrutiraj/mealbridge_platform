# FoodBridge 🌿

> **Connecting Surplus Food With Communities in Need**  
> A premium social-impact platform bridging commercial kitchens, hotels, bakeries, and event caterers with local NGOs, shelters, and volunteer couriers.

---

## 🎨 Tech Stack & Libraries

- **Framework**: React 18
- **Build Tool**: Vite 5
- **Styling**: Tailwind CSS v3
- **Icons**: Lucide React
- **Typography**: Playfair Display (Headings) & DM Sans (Body)
- **Persistence**: Browser `localStorage` (Simulated telemetry and audit ledger)

---

## 🚀 Getting Started

### Prerequisites
Make sure you have [Node.js](https://nodejs.org/) installed (v18 or higher recommended).

### 1. Installation
In the project root directory, install all required dependencies:
```bash
npm install
```

### 2. Development Server
Start the local development server:
```bash
npm run dev
```
Open your browser and navigate to `http://localhost:3000` (or the port specified in terminal).

### 3. Production Build
Generate an optimized, minified production build:
```bash
npm run build
```
This produces the deployable static output in the `dist/` directory.

### 4. Preview Production Build
Preview the production build locally:
```bash
npm run preview
```

---

## 📁 Project Structure

```
foodbridge/
├── index.html                   # HTML entry point with Google Fonts
├── package.json                 # Project dependencies & scripts
├── vite.config.js               # Vite configuration
├── tailwind.config.js           # Brand color system & typography config
├── postcss.config.js            # PostCSS configuration for Tailwind CSS
├── README.md                    # Project documentation
└── src/
    ├── main.jsx                 # React root DOM rendering
    ├── index.css                # Global styles, scrollbars & utilities
    ├── App.jsx                  # Main application state, modals & toasts
    ├── data/
    │   └── mockData.js          # Baseline illustrative metrics, steps, and stories
    ├── utils/
    │   └── storage.js           # Browser localStorage persistence & telemetry calculator
    └── components/
        ├── Navbar.jsx           # Sticky glassmorphism header & mobile drawer
        ├── Hero.jsx             # Editorial headline, photography & status cards
        ├── ProblemSection.jsx   # Hunger vs. waste crisis with root-cause breakdown
        ├── SolutionSection.jsx  # Comparison matrix: Ad-Hoc vs FoodBridge Pipeline
        ├── HowItWorks.jsx       # 4-stage velocity pipeline (Share, Connect, Coordinate, Deliver)
        ├── Features.jsx         # 6 core system capabilities with interactive spec viewer
        ├── ImpactDashboard.jsx  # Live telemetry ledger, animated metrics & category filters
        ├── BeyondThePlate.jsx   # Master storytelling: 5-stage pipeline + 4 visual chapters
        ├── RescueJourneyInteractive.jsx # 5-stage interactive product visualization
        ├── StorySection.jsx     # Re-exports BeyondThePlate for compatibility
        ├── CommunitySection.jsx # Stakeholder pathways (Chefs, Shelters, Couriers) & voices
        ├── CtaSection.jsx       # Editorial conversion banner with quick action triggers
        ├── Footer.jsx           # Mission statement, legal compliance & demo reset button
        ├── Modal.jsx            # Accessible popup dialog wrapper with backdrop blur
        ├── DonateModal.jsx      # Surplus food listing form with validation & safety tags
        ├── VolunteerModal.jsx   # Courier onboarding form (vehicle, shift, thermal bag)
        ├── NgoModal.jsx         # Shelter verification & refrigeration capacity form
        └── Toast.jsx            # Notification toast alerts with demo mode indicators
```

---

## 🎨 Color Palette

| Token | Hex | Role |
| :--- | :--- | :--- |
| **Deep Forest Green** | `#123B2A` | Primary brand anchor |
| **Emerald** | `#245B40` | Freshness & safety verification |
| **Warm Ivory** | `#F7F4EB` | Organic, welcoming canvas |
| **Muted Sage** | `#A9BDA7` | Gentle dividers & badges |
| **Champagne Gold** | `#D9A45B` | Accent highlights & CTAs |
| **Soft Charcoal** | `#292E29` | High-legibility editorial text |

---

## 📄 License
MIT License. Created for social impact demonstration.
