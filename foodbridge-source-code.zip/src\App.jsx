import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProblemSection from './components/ProblemSection';
import SolutionSection from './components/SolutionSection';
import HowItWorks from './components/HowItWorks';
import Features from './components/Features';
import ImpactDashboard from './components/ImpactDashboard';
import StorySection from './components/StorySection';
import CommunitySection from './components/CommunitySection';
import CtaSection from './components/CtaSection';
import Footer from './components/Footer';
import DonateModal from './components/DonateModal';
import VolunteerModal from './components/VolunteerModal';
import NgoModal from './components/NgoModal';
import Toast from './components/Toast';

import { 
  getStats, 
  getRescues, 
  addDonation, 
  addVolunteer, 
  addNgo, 
  resetDemoData 
} from './utils/storage';

export default function App() {
  // Application Data State
  const [stats, setStats] = useState(getStats);
  const [rescues, setRescues] = useState(getRescues);

  // Modal State
  const [isDonateOpen, setIsDonateOpen] = useState(false);
  const [isVolunteerOpen, setIsVolunteerOpen] = useState(false);
  const [isNgoOpen, setIsNgoOpen] = useState(false);

  // Toast Notification State
  const [toast, setToast] = useState(null);

  const showToast = (title, message, type = 'success', isDemo = true) => {
    setToast({ title, message, type, isDemo });
  };

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 6000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Handlers
  const handleDonateSuccess = (donationData) => {
    const { updatedStats, updatedRescues } = addDonation(donationData);
    setStats(updatedStats);
    setRescues(updatedRescues);

    showToast(
      'Surplus Food Rescue Listed',
      `"${donationData.foodDescription || 'Donation'}" added to your browser ledger. The Live Impact dashboard has been updated in real-time.`,
      'success',
      true
    );

    // Smoothly scroll to impact dashboard to see the new item
    setTimeout(() => {
      document.querySelector('#impact')?.scrollIntoView({ behavior: 'smooth' });
    }, 500);
  };

  const handleVolunteerSuccess = (volunteerData) => {
    addVolunteer(volunteerData);
    setStats(getStats());

    showToast(
      'Volunteer Courier Profile Registered',
      `Thank you, ${volunteerData.fullName}! Your volunteer record is saved in your local demo ledger.`,
      'success',
      true
    );
  };

  const handleNgoSuccess = (ngoData) => {
    addNgo(ngoData);
    setStats(getStats());

    showToast(
      'NGO Partnership Application Submitted',
      `${ngoData.ngoName} has been recorded in your demonstration ledger for review.`,
      'success',
      true
    );
  };

  const handleResetData = () => {
    const fresh = resetDemoData();
    setStats(fresh.stats);
    setRescues(fresh.rescues);

    showToast(
      'Demonstration Ledger Reset',
      'Local storage records and live dispatch metrics have been restored to initial sample baseline.',
      'info',
      false
    );
  };

  return (
    <div className="min-h-screen bg-ivory text-charcoal font-sans selection:bg-gold-brand selection:text-forest-900">
      
      {/* Navigation */}
      <Navbar
        onOpenDonate={() => setIsDonateOpen(true)}
        onOpenVolunteer={() => setIsVolunteerOpen(true)}
        onOpenNgo={() => setIsNgoOpen(true)}
      />

      {/* Main Content Sections */}
      <main>
        {/* 1. Hero Section */}
        <Hero
          onOpenDonate={() => setIsDonateOpen(true)}
          onOpenVolunteer={() => setIsVolunteerOpen(true)}
          onOpenNgo={() => setIsNgoOpen(true)}
        />

        {/* 2. Problem Section */}
        <ProblemSection />

        {/* 3. Solution Section */}
        <SolutionSection
          onOpenDonate={() => setIsDonateOpen(true)}
          onOpenNgo={() => setIsNgoOpen(true)}
        />

        {/* 4. How It Works (Share, Connect, Coordinate, Deliver) */}
        <HowItWorks
          onOpenDonate={() => setIsDonateOpen(true)}
        />

        {/* 5. Features Section */}
        <Features
          onOpenDonate={() => setIsDonateOpen(true)}
          onOpenVolunteer={() => setIsVolunteerOpen(true)}
          onOpenNgo={() => setIsNgoOpen(true)}
        />

        {/* 6. Live Impact Dashboard & Telemetry */}
        <ImpactDashboard
          stats={stats}
          rescues={rescues}
          onResetData={handleResetData}
          onOpenDonate={() => setIsDonateOpen(true)}
        />

        {/* 7. Storytelling: Beyond The Plate & Animated Journey */}
        <StorySection
          onOpenDonate={() => setIsDonateOpen(true)}
          onOpenVolunteer={() => setIsVolunteerOpen(true)}
        />

        {/* 8. Community Participation & Voices */}
        <CommunitySection
          onOpenDonate={() => setIsDonateOpen(true)}
          onOpenVolunteer={() => setIsVolunteerOpen(true)}
          onOpenNgo={() => setIsNgoOpen(true)}
        />

        {/* 9. Final Call to Action */}
        <CtaSection
          onOpenDonate={() => setIsDonateOpen(true)}
          onOpenVolunteer={() => setIsVolunteerOpen(true)}
          onOpenNgo={() => setIsNgoOpen(true)}
        />
      </main>

      {/* 10. Professional Footer */}
      <Footer
        onResetData={handleResetData}
        onOpenDonate={() => setIsDonateOpen(true)}
        onOpenVolunteer={() => setIsVolunteerOpen(true)}
        onOpenNgo={() => setIsNgoOpen(true)}
      />

      {/* Interactive Modals */}
      <DonateModal
        isOpen={isDonateOpen}
        onClose={() => setIsDonateOpen(false)}
        onSubmitSuccess={handleDonateSuccess}
      />

      <VolunteerModal
        isOpen={isVolunteerOpen}
        onClose={() => setIsVolunteerOpen(false)}
        onSubmitSuccess={handleVolunteerSuccess}
      />

      <NgoModal
        isOpen={isNgoOpen}
        onClose={() => setIsNgoOpen(false)}
        onSubmitSuccess={handleNgoSuccess}
      />

      {/* Global Toast Notification */}
      <Toast
        toast={toast}
        onClose={() => setToast(null)}
      />

    </div>
  );
}
