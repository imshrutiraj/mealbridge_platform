import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Bike, 
  ArrowRight, 
  Sparkles, 
  ChefHat, 
  Network, 
  HeartHandshake, 
  Clock, 
  ShieldCheck,
  CheckCircle2,
  Utensils
} from 'lucide-react';
import RescueJourneyInteractive from './RescueJourneyInteractive';

export default function BeyondThePlate({ onOpenDonate, onOpenVolunteer }) {
  const [activeChapter, setActiveChapter] = useState(0);

  const chapters = [
    {
      id: 'chapter-1',
      number: '01',
      tag: 'CHAPTER 01 — THE UNCLAIMED MEAL',
      title: 'The Evening Rush Ends. Sustenance Awaits.',
      leadQuote: '"The evening rush is over. Freshly prepared meals remain. But good food deserves a better destination."',
      narrative: 'In the quiet after the dinner rush, culinary kitchens often face a difficult reality: hotel pans of slow-roasted root vegetables, fresh artisanal focaccia, and delicate braised entrées prepared with supreme care sit unconsumed. In traditional setups, strict liability fears and lack of logistics relegate this bounty to dumpsters. At FoodBridge partner kitchens, the closing ritual is different: chefs lovingly portion each dish into food-grade, thermal containers, ensuring every calorie retains its flavor, nutrition, and dignity.',
      image: 'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=1400&q=85',
      imageCaption: 'Chef packaging untouched Mediterranean risotto and warm sourdough at kitchen closing',
      badge: 'Origin: Commercial Kitchen',
      microDetail: {
        metric: '< 60s',
        label: 'To pack & log surplus'
      }
    },
    {
      id: 'chapter-2',
      number: '02',
      tag: 'CHAPTER 02 — THE CONNECTION',
      title: 'The Algorithmic Bridge Between Two Worlds.',
      leadQuote: '"One simple connection brings surplus food closer to the people who need it."',
      narrative: 'With three taps on a kitchen tablet, the batch is recorded: portions logged, allergen badges applied, and temperature verified. Across the city, 2.4 kilometers away, a verified non-profit shelter receives an instant ping. FoodBridge’s matching engine checks live bed counts and walk-in refrigeration capacity. No frantic phone calls at 11 PM. No administrative bottlenecks. Just pure, intelligent routing connecting abundance to community readiness.',
      image: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=1400&q=85',
      imageCaption: 'Digital matching algorithm linking kitchen surplus to nearby shelter capacity in sub-seconds',
      badge: 'FoodBridge Routing Engine',
      microDetail: {
        metric: '2.4 km',
        label: 'Average shelter proximity'
      }
    },
    {
      id: 'chapter-3',
      number: '03',
      tag: 'CHAPTER 03 — THE HELPING HANDS',
      title: 'Civic Couriers Turning Transit Into Purpose.',
      leadQuote: '"Behind every successful delivery is a person who chooses to make a difference."',
      narrative: 'Marcus, an evening volunteer on an electric cargo bike, accepts the dispatch notification within two minutes. He arrives at the kitchen loading dock, transfers the containers into certified thermal insulation packs, and begins the journey through quiet city streets. Rain or chill, the food remains locked at safe serving temperatures. Every pedal stroke is a quiet affirmation of community solidarity.',
      image: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=1400&q=85',
      imageCaption: 'Volunteer courier securing temperature-safe insulated containers for urban delivery',
      badge: 'Civic Logistics Network',
      microDetail: {
        metric: '22 Mins',
        label: 'Average transit duration'
      }
    },
    {
      id: 'chapter-4',
      number: '04',
      tag: 'CHAPTER 04 — BEYOND THE PLATE',
      title: 'Dignity Restored Around a Shared Table.',
      leadQuote: '"A meal that might have gone to waste becomes nourishment, dignity and hope."',
      narrative: 'At 22:15, steam rises as the containers are opened inside the community shelter. The room fills with the aroma of freshly roasted herbs and baked bread. For the 45 individuals gathered around the wooden tables—working parents, unhoused neighbors, and veterans—this is not institutional ration. It is a chef-crafted meal that restores human dignity and reminds everyone that they are seen, valued, and cared for.',
      image: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=1400&q=85',
      imageCaption: 'Neighbors and shelter residents gathering to share warm, chef-prepared dinner',
      badge: 'Community Sanctuaries',
      microDetail: {
        metric: '45 Plates',
        label: 'Nourished with dignity tonight'
      }
    }
  ];

  return (
    <section 
      id="beyond-the-plate" 
      className="py-28 bg-forest-900 text-ivory relative overflow-hidden"
    >
      {/* Invisible anchor target for backwards compatibility with '#journey' */}
      <span id="journey" className="absolute top-0 -mt-20 block" />

      {/* Decorative ambient gradients */}
      <div className="absolute inset-0 bg-grain opacity-20 pointer-events-none" />
      <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-emerald-brand/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-[600px] h-[600px] bg-gold-brand/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Master Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center space-x-2 text-gold-brand text-xs font-semibold uppercase tracking-widest mb-3">
            <span className="w-8 h-px bg-gold-brand" />
            <span>BEYOND THE PLATE</span>
            <span className="w-8 h-px bg-gold-brand" />
          </div>
          
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-ivory leading-[1.12]">
            Every meal has a journey. <br />
            <span className="italic font-normal text-gold-light">
              Every connection creates an impact.
            </span>
          </h2>
          
          <p className="mt-5 text-base sm:text-lg text-sage-light leading-relaxed font-sans max-w-2xl mx-auto">
            Step inside the living pipeline that turns end-of-day kitchen surplus into hot, dignified nourishment for communities across our city.
          </p>
        </div>

        {/* 1. Interactive Architectural Journey (RESTAURANT → FOODBRIDGE → NGO → VOLUNTEER → COMMUNITY) */}
        <div className="mt-16">
          <RescueJourneyInteractive />
        </div>

        {/* 2. Visual Chapter Progress Bar */}
        <div className="mt-24 pt-8 border-t border-forest-800">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-10">
            <div>
              <span className="text-[11px] uppercase font-bold tracking-widest text-gold-brand">
                Immersive Visual Story
              </span>
              <h3 className="font-serif text-2xl font-bold text-ivory mt-0.5">
                The Four Chapters of a Single Rescue
              </h3>
            </div>

            {/* Chapter Jump Selector Pills */}
            <div className="flex items-center space-x-2 bg-forest-800/80 p-1.5 rounded-2xl border border-forest-700">
              {chapters.map((ch, idx) => (
                <button
                  key={ch.id}
                  type="button"
                  onClick={() => {
                    setActiveChapter(idx);
                    document.getElementById(ch.id)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center space-x-1.5 ${
                    activeChapter === idx
                      ? 'bg-gold-brand text-forest-900 shadow-md font-bold'
                      : 'text-sage-light hover:text-ivory'
                  }`}
                >
                  <span>Ch. {ch.number}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 3. The Four Chapters Alternating Story Feed */}
          <div className="space-y-24 relative">
            
            {/* Elegant vertical connecting timeline */}
            <div className="hidden lg:block absolute left-1/2 top-12 bottom-24 -translate-x-1/2 w-0.5 bg-gradient-to-b from-forest-700 via-gold-brand/40 to-forest-700 -z-0" />

            {chapters.map((chapter, idx) => {
              const isEven = idx % 2 === 0;

              return (
                <div
                  key={chapter.id}
                  id={chapter.id}
                  onMouseEnter={() => setActiveChapter(idx)}
                  className="relative z-10 pt-4"
                >
                  <div className={`grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-14 items-center ${
                    isEven ? '' : 'lg:flex-row-reverse'
                  }`}>
                    
                    {/* Cinematic Photograph Column */}
                    <div className={`lg:col-span-6 ${isEven ? 'lg:order-1' : 'lg:order-2'}`}>
                      <div className="relative rounded-3xl overflow-hidden shadow-2xl border-2 border-forest-700/80 bg-forest-800 group">
                        
                        {/* Image */}
                        <div className="aspect-[4/3] w-full overflow-hidden">
                          <img
                            src={chapter.image}
                            alt={chapter.title}
                            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                            loading="lazy"
                          />
                        </div>

                        {/* Gradient overlay */}
                        <div className="absolute inset-0 bg-gradient-to-t from-forest-900/90 via-forest-900/20 to-transparent" />

                        {/* Top Badge */}
                        <div className="absolute top-4 left-4">
                          <span className="px-3 py-1 rounded-full bg-forest-900/85 backdrop-blur-md text-[10px] uppercase font-bold tracking-widest text-gold-brand border border-forest-700">
                            {chapter.badge}
                          </span>
                        </div>

                        {/* Micro Spec Floating Pill */}
                        <div className="absolute top-4 right-4 bg-forest-900/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-forest-700 text-right">
                          <div className="text-[10px] text-sage-light uppercase tracking-wider font-semibold">
                            {chapter.microDetail.label}
                          </div>
                          <div className="font-serif text-xs font-bold text-gold-light">
                            {chapter.microDetail.metric}
                          </div>
                        </div>

                        {/* Bottom Image Caption */}
                        <div className="absolute bottom-4 left-4 right-4 text-xs text-sage-light">
                          <p className="line-clamp-2 italic">
                            "{chapter.imageCaption}"
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Editorial Text Story Column */}
                    <div className={`lg:col-span-6 space-y-5 ${isEven ? 'lg:order-2' : 'lg:order-1'}`}>
                      
                      {/* Chapter Heading & Large Serif Number */}
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="text-xs uppercase font-bold tracking-widest text-gold-brand mb-1">
                            {chapter.tag}
                          </div>
                          <h4 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-ivory tracking-tight leading-snug">
                            {chapter.title}
                          </h4>
                        </div>
                        
                        <span className="font-serif text-5xl sm:text-6xl font-extrabold text-forest-700/60 select-none pl-4">
                          {chapter.number}
                        </span>
                      </div>

                      {/* Prominent Lead Quote */}
                      <blockquote className="p-4 rounded-xl bg-forest-800/70 border-l-4 border-gold-brand text-sm sm:text-base italic text-gold-light/95 leading-relaxed font-serif">
                        {chapter.leadQuote}
                      </blockquote>

                      {/* Detailed Storytelling Prose */}
                      <p className="text-xs sm:text-sm text-sage-light leading-relaxed font-sans">
                        {chapter.narrative}
                      </p>

                      {/* Interactive Step Milestone Marker */}
                      <div className="pt-2 flex items-center space-x-3 text-xs text-sage-light">
                        <CheckCircle2 className="w-4 h-4 text-emerald-brand flex-shrink-0" />
                        <span className="font-medium text-ivory/90">
                          Milestone {chapter.number} Verified in Chain-of-Custody
                        </span>
                      </div>

                    </div>

                  </div>
                </div>
              );
            })}

          </div>
        </div>

        {/* 4. Grand Finale Callout & Buttons */}
        <div className="mt-28 bg-forest-800/80 border border-forest-700/90 rounded-3xl p-8 sm:p-14 text-center max-w-3xl mx-auto shadow-2xl relative overflow-hidden">
          
          {/* Subtle glow */}
          <div className="absolute inset-0 bg-gradient-to-b from-gold-brand/5 to-transparent pointer-events-none" />

          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-gold-brand/15 text-gold-brand text-xs font-semibold uppercase tracking-wider mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>The Power of Collective Action</span>
          </div>

          <h3 className="font-serif text-3xl sm:text-4xl md:text-5xl font-extrabold text-ivory leading-tight">
            "One surplus. One connection. Many lives touched."
          </h3>

          <p className="mt-4 text-xs sm:text-sm text-sage-light max-w-lg mx-auto leading-relaxed">
            Every day, kitchens and volunteers demonstrate that city hunger can be solved when logistics meets empathy. Join the network today.
          </p>

          {/* Action Buttons */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              type="button"
              onClick={onOpenDonate}
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gold-brand hover:bg-gold-light text-forest-900 text-xs uppercase tracking-wider font-bold shadow-xl hover:shadow-2xl transition-all flex items-center justify-center space-x-2 group"
            >
              <Heart className="w-4 h-4 fill-forest-900 group-hover:scale-110 transition-transform" />
              <span>Donate Food</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              type="button"
              onClick={onOpenVolunteer}
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-forest-900 hover:bg-forest-700 border border-sage/40 text-ivory text-xs uppercase tracking-wider font-semibold transition-all flex items-center justify-center space-x-2"
            >
              <Bike className="w-4 h-4 text-gold-brand" />
              <span>Become a Volunteer</span>
            </button>
          </div>

          {/* Illustrative Disclaimer Note */}
          <div className="mt-8 pt-6 border-t border-forest-700/60 text-[11px] text-sage-light/70 max-w-md mx-auto leading-normal">
            ✦ Illustrative Journey: This represents the typical four-stage life cycle of a FoodBridge rescue to demonstrate system mechanics. No real individual beneficiaries or donor names are fabricated.
          </div>

        </div>

      </div>
    </section>
  );
}
