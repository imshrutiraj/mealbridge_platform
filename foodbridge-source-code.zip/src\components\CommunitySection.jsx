import React, { useState } from 'react';
import { Quote, Utensils, Building2, Bike, HeartHandshake, CheckCircle } from 'lucide-react';
import { TESTIMONIALS } from '../data/mockData';

export default function CommunitySection({ onOpenDonate, onOpenVolunteer, onOpenNgo }) {
  const [activeAudience, setActiveAudience] = useState('restaurants');

  const audiences = [
    {
      id: 'restaurants',
      label: 'Restaurants & Hotels',
      icon: <Utensils className="w-4 h-4" />,
      title: 'Turn Surplus Into Corporate Sustainability & Civic Pride',
      description: 'Streamline nightly kitchen closures with scheduled pickups. Fulfill CSR goals, receive verified tax receipts, and protect your team with complete Good Samaritan legal immunity.',
      bullets: [
        'Single-click dispatch for unscheduled surplus',
        'Automatic donation value receipts for tax deductions',
        'Direct positive press & sustainable brand recognition'
      ],
      actionText: 'Join as Food Donor',
      action: onOpenDonate
    },
    {
      id: 'ngos',
      label: 'Shelters & NGOs',
      icon: <Building2 className="w-4 h-4" />,
      title: 'High-Quality Prepared Nutrition Delivered Directly to Your Door',
      description: 'Relieve strained meal program budgets by receiving chef-crafted, temperature-checked entrées and fresh produce tailored to your kitchen capacity.',
      bullets: [
        '100% free food delivery for verified 501(c)(3) charities',
        'Advance dietary alerts (allergens, halal, vegan, kosher)',
        'Predictable recurring distribution drops from partner bakeries'
      ],
      actionText: 'Apply as Verified NGO',
      action: onOpenNgo
    },
    {
      id: 'volunteers',
      label: 'Civic Couriers',
      icon: <Bike className="w-4 h-4" />,
      title: 'Pedal or Drive to Nourish Your Neighborhood',
      description: 'Spend 30 minutes delivering meals on your daily bike commute or weekend drive. Directly see the impact of your pedaling as you hand off hot meals to community tables.',
      bullets: [
        'Hyperlocal assignments within 10 blocks of your route',
        'Provided high-spec thermal insulated backpack or car container',
        'Certified community service hours for resume & education'
      ],
      actionText: 'Register as Courier',
      action: onOpenVolunteer
    }
  ];

  const currentAudience = audiences.find((a) => a.id === activeAudience) || audiences[0];

  return (
    <section id="community" className="py-24 bg-ivory text-charcoal relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center space-x-2 text-forest-700 text-xs font-semibold uppercase tracking-widest mb-3">
            <span className="w-6 h-px bg-forest-700" />
            <span>The Shared Ecosystem</span>
            <span className="w-6 h-px bg-forest-700" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-forest-900 leading-tight">
            A Coalition of Kitchens, Couriers, and Community Sanctuaries.
          </h2>
          <p className="mt-4 text-base sm:text-lg text-charcoal/80 leading-relaxed font-sans">
            FoodBridge thrives because every participant finds value, dignity, and purpose in the exchange.
          </p>
        </div>

        {/* Audience Segment Tabs */}
        <div className="flex justify-center mt-12">
          <div className="inline-flex p-1.5 rounded-2xl bg-sage-light/30 border border-sage/40">
            {audiences.map((aud) => (
              <button
                key={aud.id}
                onClick={() => setActiveAudience(aud.id)}
                className={`flex items-center space-x-2 px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                  activeAudience === aud.id
                    ? 'bg-forest-900 text-ivory shadow-sm'
                    : 'text-charcoal hover:text-forest-900'
                }`}
              >
                {aud.icon}
                <span>{aud.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Selected Audience Spotlight Card */}
        <div className="mt-10 bg-white rounded-3xl border border-sage/40 p-8 sm:p-12 shadow-soft-editorial">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 space-y-4">
              <span className="text-xs uppercase font-bold tracking-widest text-emerald-brand">
                Participate with FoodBridge
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-forest-900 leading-tight">
                {currentAudience.title}
              </h3>
              <p className="text-sm sm:text-base text-charcoal/80 leading-relaxed">
                {currentAudience.description}
              </p>

              <div className="space-y-2.5 pt-2">
                {currentAudience.bullets.map((b, idx) => (
                  <div key={idx} className="flex items-center space-x-2 text-xs sm:text-sm text-forest-900 font-medium">
                    <CheckCircle className="w-4 h-4 text-emerald-brand flex-shrink-0" />
                    <span>{b}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-4 flex flex-col justify-center items-start lg:items-end">
              <button
                type="button"
                onClick={currentAudience.action}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-forest-900 hover:bg-forest-800 text-ivory text-xs uppercase tracking-wider font-bold transition-all shadow-md hover:shadow-lg flex items-center justify-center space-x-2"
              >
                <span>{currentAudience.actionText}</span>
              </button>
              <span className="text-[11px] text-charcoal-muted mt-2">
                Free to register • 100% Non-Profit Operation
              </span>
            </div>
          </div>
        </div>

        {/* Real Testimonial Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          {TESTIMONIALS.map((t, idx) => (
            <div
              key={idx}
              className="bg-ivory-light border border-sage/40 rounded-2xl p-7 flex flex-col justify-between hover:shadow-soft-editorial hover:border-forest-900/40 transition-all duration-300"
            >
              <div>
                <Quote className="w-7 h-7 text-gold-brand/60 mb-3" />
                <p className="text-xs sm:text-sm text-charcoal/80 italic leading-relaxed">
                  "{t.quote}"
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-sage/30 flex items-center space-x-3">
                <img
                  src={t.image}
                  alt={t.name}
                  className="w-11 h-11 rounded-full object-cover border-2 border-forest-900/20"
                />
                <div>
                  <div className="font-serif font-bold text-forest-900 text-sm">
                    {t.name}
                  </div>
                  <div className="text-[11px] text-charcoal-muted">
                    {t.role} • <span className="text-forest-700 font-semibold">{t.org}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
