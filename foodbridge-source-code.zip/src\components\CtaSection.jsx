import React from 'react';
import { Heart, ArrowRight, Bike, Building2, Sparkles } from 'lucide-react';

export default function CtaSection({ onOpenDonate, onOpenVolunteer, onOpenNgo }) {
  return (
    <section className="py-24 bg-forest-900 text-ivory relative overflow-hidden">
      {/* Glow effect */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-emerald-brand/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="bg-forest-800/80 border border-forest-700/90 rounded-3xl p-8 sm:p-14 lg:p-16 text-center max-w-4xl mx-auto shadow-2xl">
          
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-gold-brand/15 border border-gold-brand/30 text-gold-light text-xs font-semibold mb-6">
            <Sparkles className="w-3.5 h-3.5 text-gold-brand" />
            <span>Join the Rapid-Response Movement</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-ivory leading-tight">
            Stop discarding tomorrow’s nutrition. <br />
            <span className="italic font-normal text-gold-light">Nourish your neighbors tonight.</span>
          </h2>

          <p className="mt-5 text-base sm:text-lg text-sage-light max-w-2xl mx-auto leading-relaxed font-sans">
            It takes under 60 seconds to register a surplus tray, a bakery batch, or apply as a community shelter receiving daily meals.
          </p>

          {/* Action Button Strip */}
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              type="button"
              onClick={onOpenDonate}
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gold-brand hover:bg-gold-light text-forest-900 text-xs uppercase tracking-wider font-bold transition-all shadow-xl hover:shadow-2xl flex items-center justify-center space-x-2 group"
            >
              <Heart className="w-4 h-4 text-forest-900 fill-forest-900 group-hover:scale-110 transition-transform" />
              <span>Donate Surplus Food</span>
              <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              type="button"
              onClick={onOpenVolunteer}
              className="w-full sm:w-auto px-7 py-4 rounded-xl bg-forest-900 hover:bg-forest-700 border border-sage/40 text-ivory text-xs uppercase tracking-wider font-semibold transition-all flex items-center justify-center space-x-2"
            >
              <Bike className="w-4 h-4 text-gold-brand" />
              <span>Volunteer Courier</span>
            </button>

            <button
              type="button"
              onClick={onOpenNgo}
              className="w-full sm:w-auto px-7 py-4 rounded-xl bg-forest-900 hover:bg-forest-700 border border-sage/40 text-ivory text-xs uppercase tracking-wider font-semibold transition-all flex items-center justify-center space-x-2"
            >
              <Building2 className="w-4 h-4 text-emerald-brand" />
              <span>Shelter Partnership</span>
            </button>
          </div>

          <div className="mt-8 text-xs text-sage-light/70">
            100% Free Platform • Tax Deductible Receipts • Zero Administrative Fees for Shelters
          </div>

        </div>
      </div>
    </section>
  );
}
