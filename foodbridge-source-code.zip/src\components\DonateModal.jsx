import React, { useState } from 'react';
import Modal from './Modal';
import { Package, Clock, ShieldCheck, MapPin, Sparkles, AlertCircle } from 'lucide-react';

export default function DonateModal({ isOpen, onClose, onSubmitSuccess }) {
  const initialForm = {
    donorType: 'Restaurant',
    donorName: '',
    contactPerson: '',
    email: '',
    phone: '',
    foodType: 'Cooked Meals',
    foodDescription: '',
    quantityKg: '',
    estimatedMeals: '',
    timePrepared: 'Within last 2 hours',
    pickupWindow: 'Within 90 minutes',
    storageTemp: 'Hot holding (>60°C)',
    location: '',
    dietaryNotes: [],
    specialInstructions: ''
  };

  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const dietaryOptions = ['Vegetarian', 'Vegan', 'Halal', 'Gluten-Free', 'Dairy-Free', 'Nut-Free'];

  const handleDietaryToggle = (tag) => {
    setFormData((prev) => {
      const exists = prev.dietaryNotes.includes(tag);
      return {
        ...prev,
        dietaryNotes: exists 
          ? prev.dietaryNotes.filter((t) => t !== tag)
          : [...prev.dietaryNotes, tag]
      };
    });
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.donorName.trim()) newErrors.donorName = 'Organization / Donor name is required';
    if (!formData.contactPerson.trim()) newErrors.contactPerson = 'Contact person is required';
    if (!formData.phone.trim()) newErrors.phone = 'Phone number is required for driver coordination';
    if (!formData.email.trim() || !formData.email.includes('@')) newErrors.email = 'Valid email is required';
    if (!formData.foodDescription.trim()) newErrors.foodDescription = 'Please briefly describe the food items';
    if (!formData.quantityKg || Number(formData.quantityKg) <= 0) newErrors.quantityKg = 'Please enter an approximate weight';
    if (!formData.location.trim()) newErrors.location = 'Pickup address / neighborhood is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      // Calculate estimated meals if not provided
      const meals = formData.estimatedMeals || Math.round(Number(formData.quantityKg) * 2);
      onSubmitSuccess({
        ...formData,
        estimatedMeals: meals
      });
      setIsSubmitting(false);
      setFormData(initialForm);
      onClose();
    }, 400);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="List Surplus Food for Rescue"
      subtitle="Connect your kitchen directly to verified local shelters and community pantries."
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Donor Classification */}
        <div className="bg-sage-light/25 p-4 rounded-xl border border-sage/40">
          <label className="block text-xs font-bold uppercase tracking-wider text-forest-900 mb-2">
            1. Donor Organization Type
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {['Restaurant', 'Hotel & Banquet', 'Caterer / Event', 'Supermarket', 'Corporate Kitchen', 'Household'].map((type) => (
              <button
                type="button"
                key={type}
                onClick={() => setFormData({ ...formData, donorType: type })}
                className={`py-2 px-3 text-xs font-medium rounded-lg border transition-all text-left ${
                  formData.donorType === type
                    ? 'bg-forest-900 text-ivory border-forest-900 shadow-sm'
                    : 'bg-ivory text-charcoal border-sage/40 hover:border-forest-700'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Contact Information */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Organization or Kitchen Name *
            </label>
            <input
              type="text"
              placeholder="e.g. Trattoria Bella Cucina"
              value={formData.donorName}
              onChange={(e) => setFormData({ ...formData, donorName: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.donorName ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.donorName && <p className="text-xs text-red-600 mt-1">{errors.donorName}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Contact Person / Title *
            </label>
            <input
              type="text"
              placeholder="e.g. Chef Marco Valenti"
              value={formData.contactPerson}
              onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.contactPerson ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.contactPerson && <p className="text-xs text-red-600 mt-1">{errors.contactPerson}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Contact Phone *
            </label>
            <input
              type="tel"
              placeholder="e.g. (555) 392-8812"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.phone ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.phone && <p className="text-xs text-red-600 mt-1">{errors.phone}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Email Address *
            </label>
            <input
              type="email"
              placeholder="kitchen@trattoriabella.com"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.email ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.email && <p className="text-xs text-red-600 mt-1">{errors.email}</p>}
          </div>
        </div>

        {/* Food Details */}
        <div className="bg-ivory-light p-4 rounded-xl border border-sage/40 space-y-4">
          <label className="block text-xs font-bold uppercase tracking-wider text-forest-900">
            2. Surplus Food Details & Safety
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-forest-900 mb-1">
                Category
              </label>
              <select
                value={formData.foodType}
                onChange={(e) => setFormData({ ...formData, foodType: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-sage/50 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900"
              >
                <option value="Cooked Meals">Cooked Meals / Buffet Entrées</option>
                <option value="Artisanal Bakery">Artisanal Bakery & Breads</option>
                <option value="Fresh Produce">Fresh Organic Produce</option>
                <option value="Chilled Salads">Chilled Prepared Salads</option>
                <option value="Packaged Pantry">Sealed Pantry Goods</option>
                <option value="Dairy & Beverages">Dairy & Fresh Beverages</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-forest-900 mb-1">
                  Weight (approx kg) *
                </label>
                <input
                  type="number"
                  placeholder="e.g. 25"
                  value={formData.quantityKg}
                  onChange={(e) => setFormData({ ...formData, quantityKg: e.target.value })}
                  className={`w-full px-3 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                    errors.quantityKg ? 'border-red-500' : 'border-sage/50'
                  }`}
                />
                {errors.quantityKg && <p className="text-xs text-red-600 mt-1">{errors.quantityKg}</p>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-forest-900 mb-1">
                  Est. Servings
                </label>
                <input
                  type="number"
                  placeholder="e.g. 50"
                  value={formData.estimatedMeals}
                  onChange={(e) => setFormData({ ...formData, estimatedMeals: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-lg border border-sage/50 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Food Description & Preparation *
            </label>
            <textarea
              rows={2}
              placeholder="e.g. 3 hotel pans of roasted herb chicken and roasted seasonal root vegetables. Untouched from catering chafing trays."
              value={formData.foodDescription}
              onChange={(e) => setFormData({ ...formData, foodDescription: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.foodDescription ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.foodDescription && <p className="text-xs text-red-600 mt-1">{errors.foodDescription}</p>}
          </div>

          {/* Dietary tags */}
          <div>
            <label className="block text-xs font-semibold text-forest-900 mb-2">
              Dietary & Allergen Tags
            </label>
            <div className="flex flex-wrap gap-1.5">
              {dietaryOptions.map((tag) => {
                const selected = formData.dietaryNotes.includes(tag);
                return (
                  <button
                    type="button"
                    key={tag}
                    onClick={() => handleDietaryToggle(tag)}
                    className={`px-2.5 py-1 rounded-full text-xs font-medium transition-colors ${
                      selected
                        ? 'bg-emerald-brand text-ivory'
                        : 'bg-sage/20 text-charcoal hover:bg-sage/40'
                    }`}
                  >
                    {selected ? '✓ ' : '+ '} {tag}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Temperature status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div>
              <label className="block text-xs font-semibold text-forest-900 mb-1">
                Current Storage Condition
              </label>
              <select
                value={formData.storageTemp}
                onChange={(e) => setFormData({ ...formData, storageTemp: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-sage/50 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-forest-900"
              >
                <option>Hot holding (&gt;60°C)</option>
                <option>Refrigerated chill (&lt;4°C)</option>
                <option>Room temperature (Bakery / dry)</option>
                <option>Frozen (-18°C)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-forest-900 mb-1">
                Requested Pickup Window
              </label>
              <select
                value={formData.pickupWindow}
                onChange={(e) => setFormData({ ...formData, pickupWindow: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-sage/50 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-forest-900"
              >
                <option>Immediate (Within 45 mins)</option>
                <option>Within 90 minutes</option>
                <option>Tonight closing (10:00 - 11:30 PM)</option>
                <option>Tomorrow Morning (07:00 - 09:00 AM)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Pickup Logistics */}
        <div>
          <label className="block text-xs font-semibold text-forest-900 mb-1">
            Pickup Address & Special Access Instructions *
          </label>
          <input
            type="text"
            placeholder="e.g. 742 Evergreen Terrace, Kitchen back loading dock (Ring bell #2)"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
              errors.location ? 'border-red-500' : 'border-sage/50'
            }`}
          />
          {errors.location && <p className="text-xs text-red-600 mt-1">{errors.location}</p>}
        </div>

        {/* Demo Notice Banner */}
        <div className="bg-gold-brand/15 border border-gold-brand/40 rounded-xl p-3.5 flex items-start space-x-3 text-xs text-charcoal">
          <Sparkles className="w-4 h-4 text-gold-dark flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-forest-900">Interactive Prototype Simulation</p>
            <p className="text-charcoal-muted mt-0.5">
              Submissions are saved locally in your browser to demonstrate real-time dashboard updates and live telemetry. No live emergency or municipal drivers are contacted.
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end space-x-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl border border-sage text-sm font-medium text-charcoal hover:bg-sage/20 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-6 py-2.5 rounded-xl bg-forest-900 hover:bg-forest-800 text-ivory text-sm font-medium shadow-md hover:shadow-lg transition-all flex items-center space-x-2"
          >
            <Package className="w-4 h-4 text-gold-brand" />
            <span>{isSubmitting ? 'Logging Donation...' : 'Publish Food Rescue'}</span>
          </button>
        </div>
      </form>
    </Modal>
  );
}
