import React, { useState } from 'react';
import { 
  Package, 
  Building2, 
  Navigation2, 
  ThermometerSnowflake, 
  Users, 
  LineChart,
  CheckCircle,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { CORE_FEATURES } from '../data/mockData';

export default function Features({ onOpenDonate, onOpenVolunteer, onOpenNgo }) {
  const [selectedFeature, setSelectedFeature] = useState(CORE_FEATURES[0]);

  const featureIcons = {
    'feature-1': <Package className="w-5 h-5 text-emerald-brand" />,
    'feature-2': <Building2 className="w-5 h-5 text-gold-brand" />,
    'feature-3': <Navigation2 className="w-5 h-5 text-forest-700" />,
    'feature-4': <ThermometerSnowflake className="w-5 h-5 text-emerald-brand" />,
    'feature-5': <Users className="w-5 h-5 text-gold-brand" />,
    'feature-6': <LineChart className="w-5 h-5 text-forest-700" />,
  };

  const featureDetails = {
    'feature-1': {
      title: 'Commercial Food Donations Engine',
      subhead: 'Instant surplus declaration with precision metadata.',
      points: [
        'Single-tap recurring pickups for nightly restaurant & bakery closures',
        'Automatic portion & nutritional calculation based on dish weights',
        'Dietary tagging: Halal, Kosher, Vegan, Gluten-Free and Nut-Free labels',
        'Automatic Good Samaritan Act liability protection verification'
      ],
      ctaText: 'List Surplus Food',
      action: onOpenDonate
    },
    'feature-2': {
      title: 'Verified NGO & Shelter Network',
      subhead: 'Ensuring rescued nourishment reaches verified non-profit tables.',
      points: [
        'Rigorous 5-point verification covering tax status & food safety certs',
        'Live storage profiling: Walk-in coolers, reach-in freezers, dry pantry',
        'Dynamic capacity matching to prevent shelter oversupply or food spoilage',
        'Direct coordination channel between donor kitchens and shelter directors'
      ],
      ctaText: 'Register as NGO Partner',
      action: onOpenNgo
    },
    'feature-3': {
      title: 'Hyperlocal Pickup Coordination',
      subhead: 'Sub-30 minute dispatch via agile urban couriers.',
      points: [
        'Decentralized radius dispatch targeting couriers within 4 km',
        'Electric cargo bike and clean vehicle routing to minimize transport emissions',
        'Real-time GPS tracking with turn-by-turn donor loading dock directions',
        'Automated contingency re-routing if a courier is delayed'
      ],
      ctaText: 'Join Courier Squad',
      action: onOpenVolunteer
    },
    'feature-4': {
      title: 'Freshness & Thermal Chain Tracking',
      subhead: 'Uncompromising food safety standards from flame to fork.',
      points: [
        'Real-time countdown timers monitoring maximum safe consumption thresholds',
        'HACCP standard thermal logging (>60°C hot holding, <4°C cold chain)',
        'Mandatory thermal insulated transport containers for all couriers',
        'Clear allergen segregation protocols during packaging and transit'
      ],
      ctaText: 'View Safety Standards',
      action: () => alert('FoodBridge adheres strictly to HACCP standards and the Bill Emerson Good Samaritan Food Donation Act.')
    },
    'feature-5': {
      title: 'Volunteer Squad & Fleet Management',
      subhead: 'Civic power mobilized for community solidarity.',
      points: [
        'Flexible 1-hour micro-shifts fitted around professional commutes',
        'Neighborhood courier squads led by experienced volunteer captains',
        'Verified volunteer service hours certified for schools and employers',
        'Comprehensive courier safety equipment and thermal bag kits'
      ],
      ctaText: 'Become a Volunteer',
      action: onOpenVolunteer
    },
    'feature-6': {
      title: 'Automated Impact Ledger & ESG Reports',
      subhead: 'Verifiable data for sustainability audits and tax deductions.',
      points: [
        'Real-time calculation of landfill diversion and averted methane emissions',
        'Quarterly corporate ESG summaries ready for annual sustainability reports',
        'Legally formatted charitable in-kind donation receipts for tax deductions',
        'Public impact widgets for donor websites and restaurant menus'
      ],
      ctaText: 'Explore Impact Ledger',
      action: () => {
        document.querySelector('#impact')?.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const currentDetail = featureDetails[selectedFeature.id];

  return (
    <section id="features" className="py-24 bg-ivory text-charcoal relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl">
          <div className="inline-flex items-center space-x-2 text-forest-700 text-xs font-semibold uppercase tracking-widest mb-3">
            <span className="w-6 h-px bg-forest-700" />
            <span>Core System Capabilities</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-forest-900 leading-tight">
            Engineered for speed, dignity, and food safety at institutional scale.
          </h2>
          <p className="mt-4 text-base sm:text-lg text-charcoal/80 leading-relaxed font-sans">
            FoodBridge brings enterprise-grade logistical precision to social impact, transforming spontaneous surplus into an organized community lifeline.
          </p>
        </div>

        {/* Feature Grid & Detail Split Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-16 items-start">
          
          {/* Left Column: Feature Selector Cards */}
          <div className="lg:col-span-5 space-y-3">
            {CORE_FEATURES.map((feature) => {
              const isSelected = selectedFeature.id === feature.id;
              return (
                <button
                  type="button"
                  key={feature.id}
                  onClick={() => setSelectedFeature(feature)}
                  className={`w-full text-left p-4 sm:p-5 rounded-2xl border transition-all duration-200 flex items-start space-x-4 ${
                    isSelected
                      ? 'bg-white border-forest-900 shadow-soft-editorial -translate-x-1'
                      : 'bg-ivory-light border-sage/40 hover:bg-white hover:border-sage'
                  }`}
                >
                  <div className={`p-2.5 rounded-xl border flex-shrink-0 transition-colors ${
                    isSelected ? 'bg-forest-900 text-ivory border-forest-900' : 'bg-white text-forest-900 border-sage/40'
                  }`}>
                    {featureIcons[feature.id]}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-brand">
                        {feature.badge}
                      </span>
                      <span className="text-[10px] font-semibold text-charcoal-muted">
                        {feature.highlight}
                      </span>
                    </div>
                    <h3 className="font-serif text-base font-bold text-forest-900 mt-1 truncate">
                      {feature.title}
                    </h3>
                    <p className="text-xs text-charcoal-muted mt-1 line-clamp-2 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Column: Deep-Dive Feature Display Box */}
          <div className="lg:col-span-7 bg-forest-900 text-ivory rounded-3xl p-8 sm:p-10 shadow-premium border border-forest-800 sticky top-28">
            <div className="flex items-center justify-between pb-6 border-b border-forest-800">
              <span className="text-xs font-bold uppercase tracking-widest text-gold-brand flex items-center">
                <Sparkles className="w-3.5 h-3.5 mr-1.5" />
                Feature Specification
              </span>
              <span className="text-xs text-sage-light bg-forest-800 px-3 py-1 rounded-full border border-forest-700">
                {selectedFeature.badge}
              </span>
            </div>

            <div className="mt-6">
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-ivory">
                {currentDetail.title}
              </h3>
              <p className="text-sm text-sage-light mt-2 leading-relaxed">
                {currentDetail.subhead}
              </p>
            </div>

            {/* Checklist of capabilities */}
            <div className="mt-8 space-y-3.5">
              {currentDetail.points.map((point, idx) => (
                <div key={idx} className="flex items-start space-x-3 text-xs sm:text-sm text-ivory">
                  <CheckCircle className="w-4 h-4 text-emerald-brand mt-0.5 flex-shrink-0" />
                  <span className="leading-relaxed text-ivory/90">{point}</span>
                </div>
              ))}
            </div>

            {/* Feature Action */}
            <div className="mt-10 pt-6 border-t border-forest-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
              <div className="text-xs text-sage-light">
                Available to all active partners at zero cost.
              </div>
              <button
                type="button"
                onClick={currentDetail.action}
                className="px-6 py-3 rounded-xl bg-gold-brand hover:bg-gold-light text-forest-900 text-xs uppercase tracking-wider font-bold transition-all flex items-center justify-center space-x-2"
              >
                <span>{currentDetail.ctaText}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
