import React, { useState } from 'react';
import { Utensils, Heart, Mail, CheckCircle2, RotateCcw, ShieldCheck, ArrowUp } from 'lucide-react';

export default function Footer({ onResetData, onOpenDonate, onOpenVolunteer, onOpenNgo }) {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e) => {
    e.preventDefault();
    if (newsletterEmail.trim() && newsletterEmail.includes('@')) {
      setSubscribed(true);
      setNewsletterEmail('');
      setTimeout(() => setSubscribed(false), 5000);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-forest-900 text-ivory border-t border-forest-800 pt-16 pb-12 font-sans relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-forest-800">
          
          {/* Brand & Mission (Col 1 & 2) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center space-x-2.5">
              <div className="w-10 h-10 rounded-xl bg-forest-800 border border-forest-700 flex items-center justify-center text-gold-brand">
                <Utensils className="w-5 h-5" />
              </div>
              <div>
                <span className="font-serif text-2xl font-bold tracking-tight text-ivory">
                  Food<span className="text-gold-light italic font-normal">Bridge</span>
                </span>
                <span className="block text-[9px] uppercase tracking-widest text-sage-light font-semibold -mt-1">
                  Social Impact Initiative
                </span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-sage-light leading-relaxed max-w-sm">
              Connecting commercial kitchens, hotels, bakeries, and event caterers with surplus food to vetted community shelters and volunteer couriers. Because wholesome food belongs on plates, never in landfills.
            </p>

            <div className="pt-2 flex items-center space-x-3 text-xs text-sage-light/80">
              <ShieldCheck className="w-4 h-4 text-emerald-brand flex-shrink-0" />
              <span>Full compliance with Bill Emerson Good Samaritan Act</span>
            </div>

            {/* Newsletter input */}
            <div className="pt-3">
              <span className="block text-xs font-semibold text-ivory mb-2">
                Subscribe to Quarterly Rescue Reports
              </span>
              {subscribed ? (
                <div className="flex items-center space-x-2 text-xs text-emerald-brand bg-forest-800 p-2.5 rounded-xl border border-emerald-brand/30">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Subscribed! Thank you for following our rescue journey.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex items-center space-x-2">
                  <input
                    type="email"
                    placeholder="Enter email address"
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    className="px-3.5 py-2.5 rounded-xl bg-forest-800 border border-forest-700 text-xs text-ivory placeholder-sage-light/50 focus:outline-none focus:ring-1 focus:ring-gold-brand w-full max-w-xs"
                    required
                  />
                  <button
                    type="submit"
                    className="px-4 py-2.5 rounded-xl bg-gold-brand hover:bg-gold-light text-forest-900 text-xs font-bold transition-colors whitespace-nowrap"
                  >
                    Join
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Nav Column 1: Navigation */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gold-brand">
              Platform
            </h4>
            <ul className="space-y-2 text-xs text-sage-light">
              <li>
                <a href="#problem" className="hover:text-ivory transition-colors">The Problem</a>
              </li>
              <li>
                <a href="#solution" className="hover:text-ivory transition-colors">The Solution</a>
              </li>
              <li>
                <a href="#how-it-works" className="hover:text-ivory transition-colors">How It Works</a>
              </li>
              <li>
                <a href="#features" className="hover:text-ivory transition-colors">Core Features</a>
              </li>
              <li>
                <a href="#impact" className="hover:text-ivory transition-colors">Live Impact Ledger</a>
              </li>
              <li>
                <a href="#beyond-the-plate" className="hover:text-ivory transition-colors">Beyond The Plate</a>
              </li>
            </ul>
          </div>

          {/* Nav Column 2: Stakeholders */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gold-brand">
              Get Involved
            </h4>
            <ul className="space-y-2 text-xs text-sage-light">
              <li>
                <button onClick={onOpenDonate} className="hover:text-ivory transition-colors text-left">
                  Donate Surplus Food
                </button>
              </li>
              <li>
                <button onClick={onOpenVolunteer} className="hover:text-ivory transition-colors text-left">
                  Volunteer Courier Squad
                </button>
              </li>
              <li>
                <button onClick={onOpenNgo} className="hover:text-ivory transition-colors text-left">
                  NGO & Shelter Partnership
                </button>
              </li>
              <li>
                <span className="text-sage-light/50 cursor-not-allowed">
                  Corporate CSR Programs
                </span>
              </li>
              <li>
                <span className="text-sage-light/50 cursor-not-allowed">
                  University Food Drives
                </span>
              </li>
            </ul>
          </div>

          {/* Nav Column 3: Food Safety & Standards */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gold-brand">
              Safety & Standards
            </h4>
            <ul className="space-y-2 text-xs text-sage-light">
              <li>HACCP Thermal Checkpoints</li>
              <li>Cold-Chain Preservation</li>
              <li>Allergen Isolation Rules</li>
              <li>Good Samaritan Protection</li>
              <li>5-Point NGO Verification</li>
              <li>Local Health Code Compliance</li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Demo Reset */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-sage-light/70">
          <div>
            © 2026 FoodBridge Platform. Built with empathy for people and the planet.
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={onResetData}
              className="hover:text-ivory flex items-center space-x-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Demo State</span>
            </button>

            <span>•</span>

            <button
              onClick={scrollToTop}
              className="hover:text-ivory flex items-center space-x-1 transition-colors"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
}
