import React from 'react';
import { Heart, ArrowRight, ShieldCheck, Clock, MapPin, Sparkles, ChefHat } from 'lucide-react';

export default function Hero({ onOpenDonate, onOpenVolunteer, onOpenNgo }) {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden bg-ivory">
      {/* Subtle organic background gradients */}
      <div className="absolute top-12 left-1/2 -translate-x-1/2 w-[1000px] h-[550px] bg-gradient-to-b from-sage/15 via-gold-brand/5 to-transparent rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Editorial Headline & Actions */}
          <div className="lg:col-span-7 space-y-8">
            {/* Pill tag */}
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-forest-900/5 border border-forest-900/15 text-forest-900 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-brand animate-pulse" />
              <span className="tracking-wide uppercase text-[10px] font-bold text-emerald-brand">
                Hyperlocal Food Rescue Network
              </span>
              <span className="text-charcoal-muted">•</span>
              <span className="text-charcoal-muted">Sub-45 Min Dispatch</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-[4rem] text-forest-900 font-extrabold tracking-tight leading-[1.08]">
              Bridging the chasm between <span className="italic font-normal text-emerald-brand underline decoration-gold-brand/40 underline-offset-8">surplus</span> and sustenance.
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg md:text-xl text-charcoal/80 max-w-2xl font-normal leading-relaxed">
              Every evening, commercial kitchens discard pristine, chef-prepared banquets while neighboring shelters run dry. FoodBridge provides the intelligent, temperature-safe routing engine connecting culinary abundance to verified community plates in minutes.
            </p>

            {/* CTA Group */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
              <button
                type="button"
                onClick={onOpenDonate}
                className="px-8 py-4 rounded-xl bg-forest-900 hover:bg-forest-800 text-ivory text-sm uppercase tracking-wider font-semibold shadow-premium hover:shadow-xl transition-all flex items-center justify-center space-x-3 group"
              >
                <Heart className="w-4 h-4 text-gold-brand group-hover:scale-125 transition-transform" />
                <span>Donate Surplus Food</span>
                <ArrowRight className="w-4 h-4 text-sage-light group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                type="button"
                onClick={onOpenVolunteer}
                className="px-7 py-4 rounded-xl border border-forest-900/30 text-forest-900 hover:bg-forest-900/5 text-sm uppercase tracking-wider font-semibold transition-all flex items-center justify-center space-x-2"
              >
                <span>Join Volunteer Squad</span>
              </button>
            </div>

            {/* Verified badges */}
            <div className="pt-6 border-t border-sage/30 grid grid-cols-3 gap-4 sm:gap-6 text-xs text-charcoal-muted">
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-emerald-brand flex-shrink-0" />
                <span className="font-medium text-forest-900">100% Vetted NGOs</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-gold-brand flex-shrink-0" />
                <span className="font-medium text-forest-900">&lt; 32m Avg Dispatch</span>
              </div>
              <div className="flex items-center space-x-2">
                <ChefHat className="w-4 h-4 text-forest-700 flex-shrink-0" />
                <span className="font-medium text-forest-900">HACCP Cold-Chain</span>
              </div>
            </div>

          </div>

          {/* Right Column: Premium Photography & Floating Live Cards */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Main Editorial Image */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white bg-sage/20 aspect-[4/5] group">
                <img
                  src="https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=1000&q=80"
                  alt="Chef packing wholesome organic artisanal stew for community donation"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-forest-900/80 via-transparent to-black/10" />
                
                {/* Image overlay caption */}
                <div className="absolute bottom-6 left-6 right-6 text-ivory">
                  <span className="px-2.5 py-1 rounded bg-gold-brand/90 text-forest-900 text-[10px] font-bold uppercase tracking-wider">
                    Chef's Daily Rescue
                  </span>
                  <p className="font-serif text-lg font-bold mt-1 text-ivory">
                    Fresh Vegetable Risotto & Artisanal Focaccia
                  </p>
                  <p className="text-xs text-sage-light mt-0.5">
                    Prepared with dignity at Trattoria Bella • Destined for Hope Haven Kitchen
                  </p>
                </div>
              </div>

              {/* Floating Top Right Card: Freshness Tracker */}
              <div className="absolute -top-6 -right-4 sm:-right-6 bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-premium border border-sage/30 max-w-[210px] hidden sm:block animate-float">
                <div className="flex items-center space-x-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-brand/10 text-emerald-brand flex items-center justify-center font-bold text-xs">
                    98%
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-charcoal-muted font-bold">Safety Index</div>
                    <div className="text-xs font-bold text-forest-900">Optimal Freshness</div>
                  </div>
                </div>
                <div className="w-full bg-sage/20 h-1.5 rounded-full mt-2.5 overflow-hidden">
                  <div className="bg-emerald-brand h-full rounded-full w-[94%]" />
                </div>
              </div>

              {/* Floating Bottom Left Card: Live Dispatch Activity */}
              <div className="absolute -bottom-6 -left-4 sm:-left-8 bg-forest-900 text-ivory p-4 rounded-2xl shadow-2xl border border-forest-800 max-w-[260px] animate-fade-in">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-gold-brand opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-gold-brand"></span>
                  </span>
                  <span className="text-[10px] uppercase font-bold tracking-widest text-gold-brand">
                    Active Delivery
                  </span>
                </div>
                <p className="text-xs font-medium text-ivory leading-snug">
                  Courier #412 en route to <span className="text-gold-light font-semibold">St. Jude Shelter</span> with 45kg fresh bakery bread.
                </p>
                <div className="flex items-center justify-between text-[10px] text-sage-light mt-2 pt-2 border-t border-forest-800">
                  <span className="flex items-center">
                    <MapPin className="w-3 h-3 mr-1 text-gold-brand" /> 1.2 miles away
                  </span>
                  <span className="text-gold-brand font-semibold">ETA: 7 mins</span>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
