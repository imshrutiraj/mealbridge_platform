import React from 'react';
import { PackagePlus, Network, Navigation, HeartHandshake, ArrowRight, ShieldCheck } from 'lucide-react';
import { HOW_IT_WORKS_STEPS } from '../data/mockData';

export default function HowItWorks({ onOpenDonate }) {
  const iconMap = {
    PackagePlus: <PackagePlus className="w-6 h-6 text-gold-brand" />,
    Network: <Network className="w-6 h-6 text-emerald-brand" />,
    Navigation: <Navigation className="w-6 h-6 text-forest-900" />,
    HeartHandshake: <HeartHandshake className="w-6 h-6 text-gold-brand" />
  };

  return (
    <section id="how-it-works" className="py-24 bg-ivory-dark/40 text-charcoal relative overflow-hidden border-y border-sage/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center space-x-2 text-forest-700 text-xs font-semibold uppercase tracking-widest mb-3">
            <span className="w-6 h-px bg-forest-700" />
            <span>The Four-Stage Velocity Pipeline</span>
            <span className="w-6 h-px bg-forest-700" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-forest-900 leading-tight">
            How FoodBridge Works: From Prep Station to Table in 45 Minutes.
          </h2>
          <p className="mt-4 text-base sm:text-lg text-charcoal/80 leading-relaxed font-sans">
            Every step is engineered for rapid execution, temperature safety, and complete accountability.
          </p>
        </div>

        {/* 4 Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-16 relative">
          
          {/* Connector line for desktop */}
          <div className="hidden lg:block absolute top-1/4 left-16 right-16 h-0.5 bg-gradient-to-r from-sage/40 via-gold-brand/40 to-emerald-brand/40 -z-0" />

          {HOW_IT_WORKS_STEPS.map((step, idx) => (
            <div
              key={step.number}
              className="bg-white rounded-2xl p-7 border border-sage/40 shadow-sm hover:shadow-soft-editorial hover:-translate-y-1.5 transition-all duration-300 relative z-10 flex flex-col justify-between group"
            >
              <div>
                {/* Step Top Bar: Number & Icon */}
                <div className="flex items-center justify-between mb-5">
                  <span className="font-serif text-3xl sm:text-4xl font-extrabold text-forest-900/20 group-hover:text-forest-900 transition-colors">
                    {step.number}
                  </span>
                  <div className="w-12 h-12 rounded-xl bg-ivory border border-sage/40 flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                    {iconMap[step.icon]}
                  </div>
                </div>

                <div className="text-[10px] uppercase font-bold tracking-widest text-emerald-brand mb-1">
                  {step.accent}
                </div>

                <h3 className="font-serif text-2xl font-bold text-forest-900 mb-1">
                  {step.title}
                </h3>
                <h4 className="text-xs font-semibold text-charcoal-muted mb-3">
                  {step.subtitle}
                </h4>

                <p className="text-xs sm:text-sm text-charcoal/70 leading-relaxed font-sans">
                  {step.description}
                </p>
              </div>

              {/* Bottom detail pill */}
              <div className="mt-6 pt-4 border-t border-sage/20 flex items-center justify-between text-[11px] font-semibold text-forest-900">
                <span>Phase {step.number} Protocol</span>
                <span className="text-gold-brand">● Verified</span>
              </div>
            </div>
          ))}

        </div>

        {/* Rapid CTA Bar */}
        <div className="mt-16 bg-forest-900 text-ivory rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-premium">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-forest-800 border border-forest-700 flex items-center justify-center text-gold-brand flex-shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-serif text-lg font-bold text-ivory">
                Have surplus food in your kitchen right now?
              </h4>
              <p className="text-xs sm:text-sm text-sage-light mt-0.5">
                Our active dispatch squad can be at your backdoor in under 35 minutes.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenDonate}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gold-brand hover:bg-gold-light text-forest-900 text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center space-x-2 flex-shrink-0"
          >
            <span>Start 60-Second Listing</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </section>
  );
}
