import React, { useState } from 'react';
import { 
  BarChart3, 
  RotateCcw, 
  Sparkles, 
  CheckCircle2, 
  Clock, 
  Truck, 
  AlertCircle, 
  PlusCircle,
  Filter,
  Flame,
  Leaf,
  Users2
} from 'lucide-react';

export default function ImpactDashboard({ 
  stats, 
  rescues, 
  onResetData, 
  onOpenDonate 
}) {
  const [filterCategory, setFilterCategory] = useState('All');

  const categories = ['All', 'Cooked Entrées', 'Bakery', 'Fresh Produce', 'Prepared Meals'];

  const filteredRescues = filterCategory === 'All'
    ? rescues
    : rescues.filter((r) => r.category?.toLowerCase().includes(filterCategory.toLowerCase()) || r.foodItem?.toLowerCase().includes(filterCategory.toLowerCase()));

  const statusBadges = {
    'Delivered': (
      <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-brand/10 text-emerald-brand border border-emerald-brand/30">
        <CheckCircle2 className="w-3 h-3 mr-1" /> Delivered
      </span>
    ),
    'In Transit': (
      <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-gold-brand/15 text-gold-dark border border-gold-brand/40 animate-pulse">
        <Truck className="w-3 h-3 mr-1" /> In Transit
      </span>
    ),
    'Matching NGO': (
      <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
        <Clock className="w-3 h-3 mr-1" /> Matching NGO
      </span>
    ),
    'Dispatch Pending': (
      <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-purple-50 text-purple-700 border border-purple-200">
        <Clock className="w-3 h-3 mr-1" /> Dispatch Pending
      </span>
    )
  };

  return (
    <section id="impact" className="py-24 bg-ivory-light text-charcoal border-t border-sage/30 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with Demo Badge */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-sage/30">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-gold-brand/15 border border-gold-brand/30 text-gold-dark text-xs font-semibold mb-3">
              <Sparkles className="w-3.5 h-3.5 text-gold-dark" />
              <span>Interactive Telemetry Engine</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-forest-900">
              Live Impact & Rescue Ledger
            </h2>
            <p className="mt-2 text-sm sm:text-base text-charcoal-muted max-w-2xl font-sans">
              Real-time audit telemetry tracking rescued nourishment, greenhouse gas prevention, and courier handoffs.
            </p>
          </div>

          {/* Reset Demo Button */}
          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={onOpenDonate}
              className="px-4 py-2.5 rounded-xl bg-forest-900 text-ivory text-xs font-semibold hover:bg-forest-800 transition-colors flex items-center space-x-1.5 shadow-sm"
            >
              <PlusCircle className="w-4 h-4 text-gold-brand" />
              <span>Simulate Donation</span>
            </button>
            <button
              type="button"
              onClick={onResetData}
              title="Reset demonstrative data stored in browser"
              className="px-3.5 py-2.5 rounded-xl border border-sage/60 text-xs font-semibold text-charcoal hover:bg-sage/20 transition-colors flex items-center space-x-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5 text-charcoal-muted" />
              <span>Reset Demo</span>
            </button>
          </div>
        </div>

        {/* Clear Notice / Disclaimer Banner */}
        <div className="mt-6 bg-forest-900/5 border border-forest-900/15 rounded-xl p-4 flex items-start space-x-3 text-xs text-charcoal/80">
          <AlertCircle className="w-4 h-4 text-forest-700 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <span className="font-bold text-forest-900 uppercase tracking-wide mr-1.5">
              Notice • Illustrative Demonstration Data:
            </span>
            The metrics and dispatch items displayed below illustrate how FoodBridge's live telemetry operates in a production city deployment. Any submissions you make through the forms are saved securely in your browser's local storage and are reflected immediately in this ledger without notifying real emergency services.
          </div>
        </div>

        {/* 4 Large Stat Metric Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mt-8">
          
          {/* Card 1: Meals */}
          <div className="bg-white p-6 rounded-2xl border border-sage/40 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between text-xs text-charcoal-muted font-semibold uppercase tracking-wider mb-2">
              <span>Meals Rescued</span>
              <Flame className="w-4 h-4 text-gold-brand" />
            </div>
            <div className="font-serif text-3xl sm:text-4xl font-extrabold text-forest-900">
              {stats.mealsRescued.toLocaleString()}+
            </div>
            <p className="text-xs text-emerald-brand font-medium mt-1">
              ↑ Rescued from landfills
            </p>
          </div>

          {/* Card 2: CO2 Averted */}
          <div className="bg-white p-6 rounded-2xl border border-sage/40 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between text-xs text-charcoal-muted font-semibold uppercase tracking-wider mb-2">
              <span>CO₂e Avoided</span>
              <Leaf className="w-4 h-4 text-emerald-brand" />
            </div>
            <div className="font-serif text-3xl sm:text-4xl font-extrabold text-forest-900">
              {(stats.co2AvertedKg / 1000).toFixed(1)} <span className="text-lg font-sans font-medium text-charcoal-muted">Tons</span>
            </div>
            <p className="text-xs text-emerald-brand font-medium mt-1">
              Zero organic methane release
            </p>
          </div>

          {/* Card 3: Verified NGOs */}
          <div className="bg-white p-6 rounded-2xl border border-sage/40 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between text-xs text-charcoal-muted font-semibold uppercase tracking-wider mb-2">
              <span>Partner Shelters</span>
              <BarChart3 className="w-4 h-4 text-forest-700" />
            </div>
            <div className="font-serif text-3xl sm:text-4xl font-extrabold text-forest-900">
              {stats.activeNgos}
            </div>
            <p className="text-xs text-charcoal-muted mt-1">
              Vetted community kitchens
            </p>
          </div>

          {/* Card 4: Active Volunteers */}
          <div className="bg-white p-6 rounded-2xl border border-sage/40 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between text-xs text-charcoal-muted font-semibold uppercase tracking-wider mb-2">
              <span>Volunteer Couriers</span>
              <Users2 className="w-4 h-4 text-gold-brand" />
            </div>
            <div className="font-serif text-3xl sm:text-4xl font-extrabold text-forest-900">
              {stats.activeVolunteers.toLocaleString()}
            </div>
            <p className="text-xs text-charcoal-muted mt-1">
              Pedaling & driving locally
            </p>
          </div>

        </div>

        {/* Real-time Rescue Activity Feed / Table */}
        <div className="mt-10 bg-white rounded-2xl border border-sage/40 shadow-sm overflow-hidden">
          
          {/* Table Toolbar */}
          <div className="p-4 sm:p-6 border-b border-sage/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-ivory-light">
            <div>
              <h3 className="font-serif text-lg font-bold text-forest-900">
                Recent Food Rescues & Active Dispatches
              </h3>
              <p className="text-xs text-charcoal-muted mt-0.5">
                Displaying latest verified handoffs across metropolitan chapters.
              </p>
            </div>

            {/* Filter pills */}
            <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 sm:pb-0">
              <Filter className="w-3.5 h-3.5 text-charcoal-muted mr-1 hidden sm:block" />
              {categories.map((cat) => (
                <button
                  type="button"
                  key={cat}
                  onClick={() => setFilterCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                    filterCategory === cat
                      ? 'bg-forest-900 text-ivory'
                      : 'bg-white text-charcoal border border-sage/40 hover:bg-sage/20'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-sage/30 bg-ivory text-[11px] font-bold uppercase tracking-wider text-charcoal-muted">
                  <th className="py-3 px-4 sm:px-6">Timestamp & Area</th>
                  <th className="py-3 px-4 sm:px-6">Donor Kitchen</th>
                  <th className="py-3 px-4 sm:px-6">Surplus Item & Quantity</th>
                  <th className="py-3 px-4 sm:px-6">Recipient Partner</th>
                  <th className="py-3 px-4 sm:px-6 text-right">Dispatch Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-sage/20 text-xs sm:text-sm font-sans">
                {filteredRescues.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-charcoal-muted">
                      No rescues match the selected category filter.
                    </td>
                  </tr>
                ) : (
                  filteredRescues.map((rescue) => (
                    <tr 
                      key={rescue.id} 
                      className={`hover:bg-ivory/50 transition-colors ${
                        rescue.isUserDemoSubmission ? 'bg-gold-brand/5' : ''
                      }`}
                    >
                      {/* Timestamp & Location */}
                      <td className="py-4 px-4 sm:px-6 align-top">
                        <div className="font-semibold text-forest-900 text-xs sm:text-sm">
                          {rescue.timestamp}
                        </div>
                        <div className="text-[11px] text-charcoal-muted mt-0.5">
                          {rescue.location}
                        </div>
                        {rescue.isUserDemoSubmission && (
                          <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-gold-brand text-forest-900 uppercase tracking-wider">
                            ★ Your Demo Listing
                          </span>
                        )}
                      </td>

                      {/* Donor */}
                      <td className="py-4 px-4 sm:px-6 align-top">
                        <div className="font-semibold text-forest-900">
                          {rescue.donorName}
                        </div>
                        <div className="text-[11px] text-emerald-brand font-medium">
                          {rescue.donorType}
                        </div>
                      </td>

                      {/* Food & Quantity */}
                      <td className="py-4 px-4 sm:px-6 align-top">
                        <div className="font-medium text-charcoal">
                          {rescue.foodItem}
                        </div>
                        <div className="text-xs text-forest-700 font-semibold mt-0.5">
                          {rescue.quantity}
                        </div>
                        <div className="text-[11px] text-charcoal-muted">
                          {rescue.freshnessWindow}
                        </div>
                      </td>

                      {/* Recipient */}
                      <td className="py-4 px-4 sm:px-6 align-top">
                        <div className="font-semibold text-forest-900">
                          {rescue.recipientNgo}
                        </div>
                        {rescue.courier && (
                          <div className="text-[11px] text-charcoal-muted mt-0.5">
                            Courier: {rescue.courier}
                          </div>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-4 px-4 sm:px-6 align-top text-right">
                        {statusBadges[rescue.status] || (
                          <span className="text-xs font-medium text-charcoal-muted">
                            {rescue.status}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Footer of Table */}
          <div className="p-4 bg-ivory-light border-t border-sage/30 text-xs text-charcoal-muted flex items-center justify-between">
            <span>Showing {filteredRescues.length} recent rescue dispatches</span>
            <span className="text-[11px]">Audit Ledger Token: #FB-2026-LIVE-DEMO</span>
          </div>
        </div>

      </div>
    </section>
  );
}
