import React, { useEffect } from 'react';
import { X } from 'lucide-react';

export default function Modal({ isOpen, onClose, title, subtitle, children }) {
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };

    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-forest-900/60 backdrop-blur-sm transition-opacity" 
        onClick={onClose}
      />

      {/* Modal Container */}
      <div className="flex min-h-full items-center justify-center p-4 sm:p-6 text-center">
        <div 
          className="relative w-full max-w-2xl transform overflow-hidden rounded-2xl bg-ivory text-left shadow-2xl transition-all border border-sage/30 my-8"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="bg-forest-900 text-ivory px-6 py-5 sm:px-8 border-b border-forest-800 flex items-start justify-between">
            <div>
              <span className="text-[11px] font-semibold uppercase tracking-widest text-gold-brand">
                FoodBridge Platform
              </span>
              <h3 className="text-xl sm:text-2xl font-serif font-bold text-ivory mt-0.5">
                {title}
              </h3>
              {subtitle && (
                <p className="text-sm text-sage-light mt-1 font-sans">
                  {subtitle}
                </p>
              )}
            </div>
            <button
              onClick={onClose}
              className="text-sage-light hover:text-ivory bg-forest-800 hover:bg-forest-700 p-2 rounded-full transition-colors ml-4"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Modal Body */}
          <div className="px-6 py-6 sm:px-8 max-h-[75vh] overflow-y-auto">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}
