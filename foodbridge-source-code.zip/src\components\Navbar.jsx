import React, { useState, useEffect } from 'react';
import { Menu, X, Heart, Utensils, Bike, Building2, ChevronDown, Sparkles } from 'lucide-react';

export default function Navbar({ onOpenDonate, onOpenVolunteer, onOpenNgo }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [joinDropdownOpen, setJoinDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'The Problem', href: '#problem' },
    { label: 'The Solution', href: '#solution' },
    { label: 'How It Works', href: '#how-it-works' },
    { label: 'Features', href: '#features' },
    { label: 'Live Impact', href: '#impact' },
    { label: 'Beyond The Plate', href: '#beyond-the-plate' },
    { label: 'Community', href: '#community' },
  ];

  const handleLinkClick = (e, href) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-ivory/95 backdrop-blur-md shadow-sm border-b border-sage/30 py-3.5'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Logo */}
          <a
            href="#"
            className="flex items-center space-x-2.5 group"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          >
            <div className="w-10 h-10 rounded-xl bg-forest-900 flex items-center justify-center text-gold-brand shadow-sm group-hover:scale-105 transition-transform">
              <Utensils className="w-5 h-5" />
            </div>
            <div>
              <span className="font-serif text-2xl font-bold tracking-tight text-forest-900 flex items-center">
                Food<span className="text-emerald-brand italic font-normal">Bridge</span>
              </span>
              <span className="block text-[9px] uppercase tracking-widest text-charcoal-muted font-semibold -mt-1">
                Zero Surplus • Zero Hunger
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-7">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className="text-xs uppercase tracking-wider font-semibold text-charcoal hover:text-emerald-brand transition-colors duration-200"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Desktop Action Buttons */}
          <div className="hidden md:flex items-center space-x-3">
            {/* Join Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setJoinDropdownOpen(!joinDropdownOpen)}
                onBlur={() => setTimeout(() => setJoinDropdownOpen(false), 200)}
                className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-forest-900 border border-sage/60 rounded-xl hover:bg-sage/20 transition-all flex items-center space-x-1.5"
              >
                <span>Partner</span>
                <ChevronDown className="w-3.5 h-3.5 text-sage-dark" />
              </button>

              {joinDropdownOpen && (
                <div className="absolute right-0 mt-2 w-52 bg-white rounded-xl shadow-premium border border-sage/30 py-2 z-50 animate-fade-in">
                  <button
                    onClick={() => {
                      setJoinDropdownOpen(false);
                      onOpenVolunteer();
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs font-medium text-charcoal hover:bg-ivory flex items-center space-x-2.5"
                  >
                    <Bike className="w-4 h-4 text-emerald-brand" />
                    <div>
                      <div className="font-semibold text-forest-900">Volunteer Courier</div>
                      <div className="text-[10px] text-charcoal-muted">Pedal or drive to deliver</div>
                    </div>
                  </button>
                  <button
                    onClick={() => {
                      setJoinDropdownOpen(false);
                      onOpenNgo();
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs font-medium text-charcoal hover:bg-ivory flex items-center space-x-2.5"
                  >
                    <Building2 className="w-4 h-4 text-gold-brand" />
                    <div>
                      <div className="font-semibold text-forest-900">Shelter / NGO Partner</div>
                      <div className="text-[10px] text-charcoal-muted">Receive fresh food daily</div>
                    </div>
                  </button>
                </div>
              )}
            </div>

            {/* Donate Surplus CTA */}
            <button
              type="button"
              onClick={onOpenDonate}
              className="px-5 py-2.5 rounded-xl bg-forest-900 hover:bg-forest-800 text-ivory text-xs uppercase tracking-wider font-semibold shadow-md hover:shadow-lg transition-all flex items-center space-x-2 group"
            >
              <Heart className="w-3.5 h-3.5 text-gold-brand group-hover:scale-110 transition-transform" />
              <span>Donate Food</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center space-x-2">
            <button
              type="button"
              onClick={onOpenDonate}
              className="px-3.5 py-1.5 rounded-lg bg-forest-900 text-ivory text-xs font-semibold"
            >
              Donate
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-forest-900 rounded-lg hover:bg-sage/20 transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-ivory border-b border-sage/30 px-6 py-5 shadow-xl animate-fade-in">
          <nav className="flex flex-col space-y-4">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className="text-sm font-semibold text-charcoal hover:text-emerald-brand py-1 border-b border-sage/20"
              >
                {link.label}
              </a>
            ))}
          </nav>
          
          <div className="mt-6 pt-4 border-t border-sage/30 flex flex-col space-y-2.5">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenDonate();
              }}
              className="w-full py-3 rounded-xl bg-forest-900 text-ivory text-sm font-semibold flex items-center justify-center space-x-2 shadow-md"
            >
              <Heart className="w-4 h-4 text-gold-brand" />
              <span>Donate Surplus Food</span>
            </button>
            
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenVolunteer();
                }}
                className="py-2.5 rounded-xl border border-sage/60 text-xs font-semibold text-forest-900 bg-white flex items-center justify-center space-x-1.5"
              >
                <Bike className="w-3.5 h-3.5 text-emerald-brand" />
                <span>Join Courier</span>
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenNgo();
                }}
                className="py-2.5 rounded-xl border border-sage/60 text-xs font-semibold text-forest-900 bg-white flex items-center justify-center space-x-1.5"
              >
                <Building2 className="w-3.5 h-3.5 text-gold-brand" />
                <span>Join as NGO</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
