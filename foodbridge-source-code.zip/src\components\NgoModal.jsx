import React, { useState } from 'react';
import Modal from './Modal';
import { Building2, Heart, ShieldCheck, Sparkles } from 'lucide-react';

export default function NgoModal({ isOpen, onClose, onSubmitSuccess }) {
  const initialForm = {
    ngoName: '',
    registrationId: '',
    directorName: '',
    email: '',
    phone: '',
    feedingCapacity: '100 - 250 meals / day',
    facilityType: 'Commercial Walk-in & Freezers',
    demographics: 'Unhoused individuals & families',
    address: '',
    specialRequirements: ''
  };

  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.ngoName.trim()) newErrors.ngoName = 'Organization name is required';
    if (!formData.registrationId.trim()) newErrors.registrationId = 'Charity / Non-profit registration number is required';
    if (!formData.directorName.trim()) newErrors.directorName = 'Contact name is required';
    if (!formData.phone.trim()) newErrors.phone = 'Phone number is required';
    if (!formData.email.trim() || !formData.email.includes('@')) newErrors.email = 'Valid official email is required';
    if (!formData.address.trim()) newErrors.address = 'Distribution center address is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      onSubmitSuccess(formData);
      setIsSubmitting(false);
      setFormData(initialForm);
      onClose();
    }, 400);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Apply for Verified NGO Food Partnership"
      subtitle="Receive fresh, inspected, chef-prepared meals for your community kitchen or distribution center."
    >
      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Organization / Shelter Name *
            </label>
            <input
              type="text"
              placeholder="e.g. Hope Haven Community Kitchen"
              value={formData.ngoName}
              onChange={(e) => setFormData({ ...formData, ngoName: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.ngoName ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.ngoName && <p className="text-xs text-red-600 mt-1">{errors.ngoName}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Registered NGO / 501(c)(3) ID *
            </label>
            <input
              type="text"
              placeholder="e.g. EIN #82-9104821"
              value={formData.registrationId}
              onChange={(e) => setFormData({ ...formData, registrationId: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.registrationId ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.registrationId && <p className="text-xs text-red-600 mt-1">{errors.registrationId}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Outreach Director / Coordinator *
            </label>
            <input
              type="text"
              placeholder="e.g. Dr. Evelyn Vance"
              value={formData.directorName}
              onChange={(e) => setFormData({ ...formData, directorName: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.directorName ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.directorName && <p className="text-xs text-red-600 mt-1">{errors.directorName}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Coordinator Phone *
            </label>
            <input
              type="tel"
              placeholder="e.g. (555) 749-1100"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.phone ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.phone && <p className="text-xs text-red-600 mt-1">{errors.phone}</p>}
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Official Email *
            </label>
            <input
              type="email"
              placeholder="outreach@hopehaven.org"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.email ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.email && <p className="text-xs text-red-600 mt-1">{errors.email}</p>}
          </div>
        </div>

        {/* Operational Capacity */}
        <div className="bg-ivory-light p-4 rounded-xl border border-sage/40 space-y-4">
          <label className="block text-xs font-bold uppercase tracking-wider text-forest-900">
            Capacity & Cold Storage Specifications
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-forest-900 mb-1">
                Average Daily Serving Capacity
              </label>
              <select
                value={formData.feedingCapacity}
                onChange={(e) => setFormData({ ...formData, feedingCapacity: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-sage/50 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900"
              >
                <option>Under 50 meals / day</option>
                <option>50 - 100 meals / day</option>
                <option>100 - 250 meals / day</option>
                <option>250 - 500 meals / day</option>
                <option>500+ meals / day (Regional hub)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-forest-900 mb-1">
                Refrigeration & Food Storage Facilities
              </label>
              <select
                value={formData.facilityType}
                onChange={(e) => setFormData({ ...formData, facilityType: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-sage/50 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900"
              >
                <option>Commercial Walk-in Coolers & Freezers</option>
                <option>Standard Commercial Reach-in Fridges</option>
                <option>Residential Grade Refrigerators</option>
                <option>Dry Goods Only (No cold chain)</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-forest-900 mb-1">
                Primary Community Demographics
              </label>
              <select
                value={formData.demographics}
                onChange={(e) => setFormData({ ...formData, demographics: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-sage/50 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900"
              >
                <option>Unhoused individuals & emergency shelter residents</option>
                <option>Low-income families & after-school youth centers</option>
                <option>Senior citizen community centers</option>
                <option>Immigrant & refugee support centers</option>
                <option>Disaster & crisis relief pop-ups</option>
              </select>
            </div>
          </div>
        </div>

        {/* Delivery Address */}
        <div>
          <label className="block text-xs font-semibold text-forest-900 mb-1">
            Physical Kitchen / Receiving Address *
          </label>
          <input
            type="text"
            placeholder="e.g. 104 Hope Avenue, Building B, North Kitchen Door"
            value={formData.address}
            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
              errors.address ? 'border-red-500' : 'border-sage/50'
            }`}
          />
          {errors.address && <p className="text-xs text-red-600 mt-1">{errors.address}</p>}
        </div>

        {/* Demo Simulation Alert */}
        <div className="bg-gold-brand/15 border border-gold-brand/40 rounded-xl p-3.5 flex items-start space-x-3 text-xs text-charcoal">
          <Sparkles className="w-4 h-4 text-gold-dark flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-forest-900">Prototype Demonstration</p>
            <p className="text-charcoal-muted mt-0.5">
              This application will be registered in your local storage demo ledger. In production, this starts our 5-step vetting and health inspection verification.
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end space-x-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl border border-sage text-sm font-medium text-charcoal hover:bg-sage/20 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-6 py-2.5 rounded-xl bg-forest-900 hover:bg-forest-800 text-ivory text-sm font-medium shadow-md hover:shadow-lg transition-all flex items-center space-x-2"
          >
            <Building2 className="w-4 h-4 text-gold-brand" />
            <span>{isSubmitting ? 'Registering...' : 'Submit NGO Application'}</span>
          </button>
        </div>
      </form>
    </Modal>
  );
}
