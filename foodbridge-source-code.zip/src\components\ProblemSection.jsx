import React from 'react';
import { Trash2, AlertTriangle, CloudRain, UtensilsCrossed, TrendingDown, Clock, Building } from 'lucide-react';

export default function ProblemSection() {
  const stats = [
    {
      value: '1.3 Billion',
      unit: 'Metric Tons Annually',
      headline: 'One-Third of Global Food Discarded',
      description: 'More than 30% of all food harvested globally never reaches a plate, discarded due to cosmetic standards, buffet buffers, and supply disconnects.',
      icon: <Trash2 className="w-6 h-6 text-red-500" />,
      tag: 'Global Waste Volume'
    },
    {
      value: '828 Million',
      unit: 'People Sleep Hungry',
      headline: 'A Crisis Living Blocks From Plenty',
      description: 'Within a 3-mile radius of Michelin-starred kitchens and banquet centers, families, veterans, and children skip essential daily nutrition.',
      icon: <UtensilsCrossed className="w-6 h-6 text-gold-brand" />,
      tag: 'Human Deprivation'
    },
    {
      value: '10 Percent',
      unit: 'Of Global GHG Emissions',
      headline: 'Landfill Rot Fuels Climate Decay',
      description: 'Decomposing organic matter in municipal landfills creates potent methane gas. If food waste were a country, it would be the third-largest emitter.',
      icon: <CloudRain className="w-6 h-6 text-sage-dark" />,
      tag: 'Ecological Fallout'
    }
  ];

  const breakdownPoints = [
    {
      title: 'The Banquet Dilemma',
      subtitle: 'Conventions & Weddings',
      text: 'Event planners intentionally overprepare by 20% to prevent empty chafing dishes. At 11 PM, tens of kilograms of untouched prime food are dumped.',
      metric: 'Up to 25% discarded'
    },
    {
      title: 'The Shelf-Life Cliff',
      subtitle: 'Artisanal Bakeries & Cafes',
      text: 'Wholesome breads, baguettes, and morning pastries have a 14-hour commercial window. Perfectly edible food becomes "unsellable" by nightfall.',
      metric: 'Over 40M loaves daily'
    },
    {
      title: 'The Cold-Chain Liability Gap',
      subtitle: 'Restaurants & Hospitality',
      text: 'Without verified temperature-safe handoff and certified courier networks, chefs fear legal liability or spoilage during transit.',
      metric: 'Logistical Blindspot'
    }
  ];

  return (
    <section id="problem" className="py-24 bg-forest-900 text-ivory relative overflow-hidden">
      {/* Decorative background grid and watermark */}
      <div className="absolute inset-0 bg-grain opacity-20 pointer-events-none" />
      <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-emerald-brand/10 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-3xl">
          <div className="inline-flex items-center space-x-2 text-gold-brand text-xs font-semibold uppercase tracking-widest mb-3">
            <span className="w-6 h-px bg-gold-brand" />
            <span>The Reality of Waste</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-ivory leading-tight">
            Hunger is not a scarcity problem. <br />
            <span className="italic font-normal text-gold-light">It is an agonizing logistics failure.</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-sage-light leading-relaxed">
            The world produces more than enough calories to sustain every man, woman, and child. Yet our urban food systems suffer from an invisible wall: food surplus and acute community hunger exist simultaneously, often separated by fewer than six city blocks.
          </p>
        </div>

        {/* 3 Large Stat Pillar Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          {stats.map((s, idx) => (
            <div
              key={idx}
              className="bg-forest-800/60 border border-forest-700/80 rounded-2xl p-8 hover:border-gold-brand/40 transition-all duration-300 hover:-translate-y-1 group relative overflow-hidden"
            >
              <div className="flex items-center justify-between mb-6">
                <span className="text-[11px] font-bold uppercase tracking-wider text-sage-light/70 bg-forest-900/60 px-3 py-1 rounded-full border border-forest-700">
                  {s.tag}
                </span>
                <div className="p-2.5 rounded-xl bg-forest-900 border border-forest-700 group-hover:scale-110 transition-transform">
                  {s.icon}
                </div>
              </div>

              <div className="font-serif text-4xl sm:text-5xl font-extrabold text-ivory tracking-tight group-hover:text-gold-light transition-colors">
                {s.value}
              </div>
              <div className="text-xs uppercase tracking-widest text-gold-brand font-semibold mt-1">
                {s.unit}
              </div>

              <h3 className="font-serif text-lg font-bold text-ivory mt-4 mb-2">
                {s.headline}
              </h3>
              <p className="text-sm text-sage-light/80 leading-relaxed font-sans">
                {s.description}
              </p>
            </div>
          ))}
        </div>

        {/* The Logistics Disconnect Breakdown */}
        <div className="mt-16 bg-forest-800/30 border border-forest-700/60 rounded-3xl p-8 sm:p-10 lg:p-12">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 pb-8 border-b border-forest-700/60">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-gold-brand">
                Root Cause Analysis
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-ivory mt-1">
                Why Does Wholesome Food End Up In Landfills?
              </h3>
            </div>
            <p className="text-sm text-sage-light max-w-lg leading-relaxed">
              Commercial kitchens are constrained by intense prep schedules and strict food safety fears. Shelters lack transport fleets. FoodBridge bridges this structural gap.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
            {breakdownPoints.map((item, idx) => (
              <div key={idx} className="space-y-3">
                <div className="text-xs font-semibold uppercase tracking-wider text-gold-brand">
                  {item.subtitle}
                </div>
                <h4 className="font-serif text-lg font-bold text-ivory">
                  {item.title}
                </h4>
                <p className="text-xs sm:text-sm text-sage-light/80 leading-relaxed">
                  {item.text}
                </p>
                <div className="pt-2 text-xs font-bold text-emerald-brand bg-forest-900/80 px-3 py-1.5 rounded-lg inline-block border border-forest-700">
                  {item.metric}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
