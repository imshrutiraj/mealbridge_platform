import React, { useState, useEffect, useRef } from 'react';
import { 
  ChefHat, 
  Network, 
  Building2, 
  Bike, 
  Users2, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck, 
  Clock, 
  MapPin, 
  CheckCircle2,
  ChevronRight
} from 'lucide-react';

export default function RescueJourneyInteractive() {
  const [activeStage, setActiveStage] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const autoPlayRef = useRef(null);

  const stages = [
    {
      id: 'restaurant',
      stepNumber: '01',
      name: 'Restaurant',
      role: 'Origin Kitchen',
      icon: ChefHat,
      badge: 'Surplus Identification',
      headline: 'Untouched Culinary Surplus Prepared with Care',
      description: 'At the conclusion of banquet or dinner service, chefs package pristine, high-grade entrées into food-grade thermal containers and log the batch in under 60 seconds.',
      specs: [
        { label: 'Listing Time', value: '< 60 Seconds' },
        { label: 'Thermal Protocol', value: 'HACCP Hot/Cold Hold' },
        { label: 'Liability Status', value: 'Good Samaritan Shield' }
      ],
      metricText: '100% Safe Packaging'
    },
    {
      id: 'foodbridge',
      stepNumber: '02',
      name: 'FoodBridge',
      role: 'Routing Engine',
      icon: Network,
      badge: 'Algorithmic Dispatch',
      headline: 'Sub-Second Local Shelter Matching',
      description: 'FoodBridge evaluates nearby verified NGOs within a 4km radius, matching dietary requirements, portion volume, and live refrigeration capacity without manual phone calls.',
      specs: [
        { label: 'Radius', value: 'Within 4.0 km' },
        { label: 'Match Latency', value: 'Sub-Second (<0.8s)' },
        { label: 'Cold Storage Check', value: 'Verified Before Dispatch' }
      ],
      metricText: 'Zero Dispatch Delay'
    },
    {
      id: 'ngo',
      stepNumber: '03',
      name: 'NGO',
      role: 'Partner Shelter',
      icon: Building2,
      badge: 'Capacity Confirmation',
      headline: 'Community Shelter Confirms Immediate Need',
      description: 'The receiving non-profit verifies dock availability and refrigeration space, ensuring incoming meals are planned directly for that evening or next morning’s service.',
      specs: [
        { label: 'Vetting', value: '5-Point Health Certified' },
        { label: 'Acceptance Rate', value: '99.4% Confirmation' },
        { label: 'Beneficiaries', value: 'Shelters & Families' }
      ],
      metricText: 'Verified 501(c)(3) Hubs'
    },
    {
      id: 'volunteer',
      stepNumber: '04',
      name: 'Volunteer',
      role: 'Civic Courier',
      icon: Bike,
      badge: 'Rapid Logistics',
      headline: 'Insulated Cold-Chain Transit in Motion',
      description: 'A neighborhood courier equipped with an insulated thermal transport kit accepts the mission, picks up the donation, and navigates city corridors in minutes.',
      specs: [
        { label: 'Average Transit', value: '22 Minutes' },
        { label: 'Mobility', value: 'E-Bike, Bike & EV' },
        { label: 'Temperature Log', value: 'Continuous Seal' }
      ],
      metricText: '< 28 Min Urban Handoff'
    },
    {
      id: 'community',
      stepNumber: '05',
      name: 'Community',
      role: 'Dignified Plates',
      icon: Users2,
      badge: 'Nourishment & Dignity',
      headline: 'Nourishment, Dignity, and Zero Waste',
      description: 'Wholesome, chef-prepared meals are served warm to families, veterans, and individuals in need. The food rescue ledger confirms completion with verified photo handoff.',
      specs: [
        { label: 'Landfill Waste', value: '0% Discarded' },
        { label: 'Dignity Standard', value: 'Restaurant-Grade Meal' },
        { label: 'Impact Proof', value: 'Verified Photo Ledger' }
      ],
      metricText: 'Plates Filled With Dignity'
    }
  ];

  // Auto-advance through the stages every 4.5 seconds unless user hovers/pauses
  useEffect(() => {
    if (!isPaused) {
      autoPlayRef.current = setInterval(() => {
        setActiveStage((prev) => (prev + 1) % stages.length);
      }, 4500);
    }
    return () => {
      if (autoPlayRef.current) clearInterval(autoPlayRef.current);
    };
  }, [isPaused, stages.length]);

  const current = stages[activeStage];

  return (
    <div 
      className="bg-forest-900/90 border border-forest-700/80 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-md relative overflow-hidden"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Subtle ambient lighting */}
      <div className="absolute -top-24 -left-24 w-72 h-72 rounded-full bg-emerald-brand/15 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-72 h-72 rounded-full bg-gold-brand/10 blur-3xl pointer-events-none" />

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-8 border-b border-forest-800">
        <div>
          <div className="inline-flex items-center space-x-2 text-gold-brand text-[11px] font-bold uppercase tracking-widest mb-1.5">
            <span className="w-2 h-2 rounded-full bg-gold-brand animate-ping" />
            <span>Interactive Architecture Visualization</span>
          </div>
          <h3 className="font-serif text-2xl sm:text-3xl font-bold text-ivory">
            The Food Rescue Flow in Action
          </h3>
          <p className="text-xs sm:text-sm text-sage-light mt-1">
            Hover or tap any stage to inspect how food moves seamlessly from kitchen surplus to community table.
          </p>
        </div>

        {/* Auto-play status indicator */}
        <div className="flex items-center space-x-2 bg-forest-800/80 border border-forest-700 px-3 py-1.5 rounded-full text-xs text-sage-light self-start sm:self-auto">
          <span className={`w-2 h-2 rounded-full ${isPaused ? 'bg-gold-brand' : 'bg-emerald-brand animate-pulse'}`} />
          <span className="text-[11px] font-medium">
            {isPaused ? 'Interactive Paused' : 'Live Simulation Cycling'}
          </span>
        </div>
      </div>

      {/* Five-Stage Journey Interactive Stepper */}
      <div className="py-8 relative">
        
        {/* Connecting track on desktop */}
        <div className="hidden lg:block absolute top-[52px] left-[7%] right-[7%] h-0.5 bg-forest-800 -z-0">
          {/* Animated progressive indicator line */}
          <div 
            className="h-full bg-gradient-to-r from-emerald-brand via-gold-brand to-emerald-brand transition-all duration-700 ease-out"
            style={{ width: `${(activeStage / (stages.length - 1)) * 100}%` }}
          />
        </div>

        {/* Five Stage Nodes */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 lg:gap-3 relative z-10">
          {stages.map((stage, idx) => {
            const IconComponent = stage.icon;
            const isActive = activeStage === idx;
            const isCompleted = idx < activeStage;

            return (
              <button
                key={stage.id}
                type="button"
                onClick={() => {
                  setActiveStage(idx);
                  setIsPaused(true);
                }}
                className={`flex flex-col items-center text-center p-3.5 sm:p-4 rounded-2xl transition-all duration-300 relative group cursor-pointer ${
                  isActive
                    ? 'bg-forest-800 border-2 border-gold-brand shadow-lg -translate-y-1'
                    : 'bg-forest-900/60 border border-forest-800 hover:border-forest-700 hover:bg-forest-800/40'
                }`}
              >
                {/* Node Icon Circle */}
                <div 
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-300 mb-3 shadow-md ${
                    isActive
                      ? 'bg-gold-brand text-forest-900 scale-110 shadow-gold-glow'
                      : isCompleted
                      ? 'bg-emerald-brand text-ivory'
                      : 'bg-forest-800 text-sage-light group-hover:text-ivory group-hover:bg-forest-700'
                  }`}
                >
                  <IconComponent className="w-6 h-6 transition-transform group-hover:scale-110" />
                </div>

                {/* Step number badge */}
                <span className={`text-[10px] font-mono font-bold tracking-widest uppercase mb-1 transition-colors ${
                  isActive ? 'text-gold-brand' : 'text-sage-light/60'
                }`}>
                  Stage {stage.stepNumber}
                </span>

                {/* Node Name */}
                <span className={`font-serif text-sm sm:text-base font-bold transition-colors ${
                  isActive ? 'text-ivory' : 'text-sage-light group-hover:text-ivory'
                }`}>
                  {stage.name}
                </span>

                {/* Subtitle Role */}
                <span className="text-[11px] text-sage-light/80 mt-0.5">
                  {stage.role}
                </span>

                {/* Active indicator dot */}
                {isActive && (
                  <span className="absolute -bottom-1 w-2 h-2 rounded-full bg-gold-brand animate-ping" />
                )}
              </button>
            );
          })}
        </div>

      </div>

      {/* Selected Stage Detail Display Panel */}
      <div className="bg-forest-800/80 border border-forest-700 rounded-2xl p-6 sm:p-8 transition-all duration-500">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 pb-6 border-b border-forest-700/70">
          
          <div className="space-y-2">
            <div className="flex items-center space-x-3">
              <span className="px-3 py-1 rounded-full text-[10px] uppercase font-bold tracking-wider bg-gold-brand text-forest-900">
                {current.badge}
              </span>
              <span className="text-xs text-sage-light font-mono">
                Stage {current.stepNumber} of 05
              </span>
            </div>
            <h4 className="font-serif text-xl sm:text-2xl font-bold text-ivory">
              {current.headline}
            </h4>
          </div>

          <div className="flex items-center space-x-2 text-xs font-semibold text-emerald-brand bg-forest-900/80 px-4 py-2 rounded-xl border border-forest-700">
            <CheckCircle2 className="w-4 h-4 text-emerald-brand flex-shrink-0" />
            <span>{current.metricText}</span>
          </div>

        </div>

        {/* Description & Technical Specs */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6 items-center">
          <div className="lg:col-span-7">
            <p className="text-xs sm:text-sm text-sage-light leading-relaxed font-sans">
              {current.description}
            </p>
          </div>

          {/* Specs Pillars */}
          <div className="lg:col-span-5 grid grid-cols-3 gap-2 sm:gap-3 bg-forest-900/60 p-4 rounded-xl border border-forest-700">
            {current.specs.map((spec, i) => (
              <div key={i} className="text-center">
                <div className="text-[10px] uppercase tracking-wider text-sage-light/70 font-semibold truncate">
                  {spec.label}
                </div>
                <div className="font-serif text-xs sm:text-sm font-bold text-ivory mt-1">
                  {spec.value}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Stepper Navigation Buttons */}
        <div className="flex items-center justify-between pt-6 mt-6 border-t border-forest-700/60 text-xs">
          <button
            type="button"
            disabled={activeStage === 0}
            onClick={() => {
              setActiveStage((prev) => Math.max(0, prev - 1));
              setIsPaused(true);
            }}
            className={`font-semibold flex items-center space-x-1 transition-colors ${
              activeStage === 0 ? 'text-sage-light/30 cursor-not-allowed' : 'text-sage-light hover:text-ivory'
            }`}
          >
            <span>← Previous Stage</span>
          </button>

          <div className="flex items-center space-x-1.5">
            {stages.map((_, dotIdx) => (
              <button
                key={dotIdx}
                type="button"
                onClick={() => {
                  setActiveStage(dotIdx);
                  setIsPaused(true);
                }}
                className={`h-1.5 rounded-full transition-all ${
                  activeStage === dotIdx ? 'w-6 bg-gold-brand' : 'w-2 bg-forest-700 hover:bg-sage-light'
                }`}
                aria-label={`Jump to stage ${dotIdx + 1}`}
              />
            ))}
          </div>

          <button
            type="button"
            disabled={activeStage === stages.length - 1}
            onClick={() => {
              setActiveStage((prev) => Math.min(stages.length - 1, prev + 1));
              setIsPaused(true);
            }}
            className={`font-semibold flex items-center space-x-1 transition-colors ${
              activeStage === stages.length - 1 ? 'text-sage-light/30 cursor-not-allowed' : 'text-gold-brand hover:text-gold-light'
            }`}
          >
            <span>Next Stage →</span>
          </button>
        </div>

      </div>

    </div>
  );
}
