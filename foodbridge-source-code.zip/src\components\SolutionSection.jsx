import React, { useState } from 'react';
import { Check, X, Shield, Zap, Route, HeartHandshake, FileText, ArrowRight } from 'lucide-react';

export default function SolutionSection({ onOpenDonate, onOpenNgo }) {
  const [activeTab, setActiveTab] = useState('comparison');

  const comparisonData = [
    {
      factor: 'Listing Speed',
      traditional: 'Frantic phone calls to charities during late-night closing rush',
      foodbridge: '60-second digital listing with auto-calculated portions and dietary tags',
      highlight: true
    },
    {
      factor: 'Logistics & Transit',
      traditional: 'Shelters must have their own van and available driver',
      foodbridge: 'Decentralized bicycle and electric vehicle volunteer courier network',
      highlight: false
    },
    {
      factor: 'Food Safety & Liability',
      traditional: 'Chefs fear donor liability; no verifiable thermal tracking',
      foodbridge: 'Good Samaritan Act compliance, digital chain-of-custody & HACCP time limits',
      highlight: true
    },
    {
      factor: 'Capacity Matching',
      traditional: 'Overwhelming a tiny soup kitchen with 200 unexpected meals',
      foodbridge: 'Smart allocation based on live bed counts and refrigeration capacity',
      highlight: false
    },
    {
      factor: 'Corporate Reporting',
      traditional: 'No paperwork or informal paper slips for accounting',
      foodbridge: 'Automated ESG impact dashboard and tax-deductible donation summaries',
      highlight: true
    }
  ];

  const pillars = [
    {
      title: 'Hyperlocal Smart Dispatch',
      description: 'Our proprietary matching engine connects donors to recipient hubs within a 4km radius, reducing transit time below 30 minutes.',
      icon: <Route className="w-5 h-5 text-emerald-brand" />,
      color: 'border-emerald-brand/30 bg-emerald-brand/5'
    },
    {
      title: 'Verified NGO Network',
      description: 'Every shelter, community pantry, and soup kitchen is pre-screened for refrigeration capacity, hygiene certification, and distribution ethics.',
      icon: <Shield className="w-5 h-5 text-forest-900" />,
      color: 'border-forest-900/20 bg-forest-900/5'
    },
    {
      title: 'Zero-Liability Safety Net',
      description: 'Complete Good Samaritan food protection integration with time-stamped digital handoffs ensuring donor confidence.',
      icon: <Zap className="w-5 h-5 text-gold-brand" />,
      color: 'border-gold-brand/40 bg-gold-brand/10'
    },
    {
      title: 'Dignified Community Serving',
      description: 'Meals are served warm, fresh, and beautifully presented, respecting the dignity of our unhoused and low-income neighbors.',
      icon: <HeartHandshake className="w-5 h-5 text-emerald-brand" />,
      color: 'border-emerald-brand/30 bg-emerald-brand/5'
    }
  ];

  return (
    <section id="solution" className="py-24 bg-ivory text-charcoal relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center space-x-2 text-forest-700 text-xs font-semibold uppercase tracking-widest mb-3">
            <span className="w-6 h-px bg-forest-700" />
            <span>The FoodBridge Architecture</span>
            <span className="w-6 h-px bg-forest-700" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-forest-900 leading-tight">
            A digital bloodstream connecting culinary surplus with community need.
          </h2>
          <p className="mt-4 text-base sm:text-lg text-charcoal/80 leading-relaxed font-sans">
            FoodBridge eliminates friction at every touchpoint. We provide the real-time software, verified non-profit matching, and volunteer dispatch that turns a late-night kitchen dilemma into warm, dignified sustenance.
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-16">
          {pillars.map((pillar, idx) => (
            <div
              key={idx}
              className={`p-6 rounded-2xl border transition-all duration-300 hover:shadow-soft-editorial hover:-translate-y-1 bg-white ${pillar.color}`}
            >
              <div className="w-10 h-10 rounded-xl bg-ivory flex items-center justify-center mb-4 border border-sage/40 shadow-sm">
                {pillar.icon}
              </div>
              <h3 className="font-serif text-lg font-bold text-forest-900 mb-2">
                {pillar.title}
              </h3>
              <p className="text-xs sm:text-sm text-charcoal/70 leading-relaxed">
                {pillar.description}
              </p>
            </div>
          ))}
        </div>

        {/* Interactive Comparison: Traditional vs FoodBridge */}
        <div className="mt-20 bg-white rounded-3xl shadow-soft-editorial border border-sage/30 overflow-hidden">
          <div className="bg-forest-900 text-ivory px-6 sm:px-10 py-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs uppercase font-bold tracking-widest text-gold-brand">
                Comparative Breakdown
              </span>
              <h3 className="font-serif text-2xl font-bold text-ivory mt-0.5">
                The Ad-Hoc Void vs. The FoodBridge Pipeline
              </h3>
            </div>
            <div className="flex items-center space-x-2 text-xs">
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-brand" />
              <span className="text-sage-light">Engineered for sub-45 min delivery</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-sage/30 bg-ivory-light text-xs font-bold uppercase tracking-wider text-forest-900">
                  <th className="py-4 px-6 sm:px-8 w-1/4">Operational Parameter</th>
                  <th className="py-4 px-6 sm:px-8 w-3/8 text-charcoal-muted">Traditional Manual Attempts</th>
                  <th className="py-4 px-6 sm:px-8 w-3/8 text-forest-900 bg-emerald-brand/5">FoodBridge Smart Infrastructure</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-sage/20 text-xs sm:text-sm">
                {comparisonData.map((row, idx) => (
                  <tr key={idx} className="hover:bg-ivory/50 transition-colors">
                    <td className="py-4 px-6 sm:px-8 font-semibold text-forest-900 align-top">
                      {row.factor}
                    </td>
                    <td className="py-4 px-6 sm:px-8 text-charcoal/70 align-top">
                      <div className="flex items-start space-x-2">
                        <X className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
                        <span>{row.traditional}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6 sm:px-8 text-forest-900 font-medium bg-emerald-brand/5 align-top">
                      <div className="flex items-start space-x-2">
                        <Check className="w-4 h-4 text-emerald-brand mt-0.5 flex-shrink-0" />
                        <span>{row.foodbridge}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-6 sm:p-8 bg-ivory-light border-t border-sage/30 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs sm:text-sm text-charcoal/80">
              Ready to transform surplus in your kitchen or register your community kitchen for rescued sustenance?
            </p>
            <div className="flex items-center space-x-3 flex-shrink-0">
              <button
                type="button"
                onClick={onOpenDonate}
                className="px-5 py-2.5 rounded-xl bg-forest-900 text-ivory text-xs font-semibold hover:bg-forest-800 transition-colors"
              >
                Donate Surplus
              </button>
              <button
                type="button"
                onClick={onOpenNgo}
                className="px-5 py-2.5 rounded-xl border border-forest-900/40 text-forest-900 text-xs font-semibold hover:bg-forest-900/5 transition-colors"
              >
                Apply as NGO Partner
              </button>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
