import React from 'react';
import BeyondThePlate from './BeyondThePlate';

export default function StorySection(props) {
  return <BeyondThePlate {...props} />;
}
