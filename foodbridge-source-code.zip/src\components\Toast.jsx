import React from 'react';
import { CheckCircle2, AlertCircle, X, Info } from 'lucide-react';

export default function Toast({ toast, onClose }) {
  if (!toast) return null;

  const icons = {
    success: <CheckCircle2 className="w-5 h-5 text-emerald-brand flex-shrink-0" />,
    error: <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />,
    info: <Info className="w-5 h-5 text-gold-brand flex-shrink-0" />
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-md w-full animate-bounce-in transition-all">
      <div className="bg-ivory-light border border-sage/40 rounded-xl shadow-premium p-4 flex items-start space-x-3 text-charcoal">
        <div className="mt-0.5">{icons[toast.type] || icons.info}</div>
        <div className="flex-1 pr-2">
          <p className="font-medium text-forest-900 text-sm">{toast.title}</p>
          <p className="text-xs text-charcoal-muted mt-0.5 leading-relaxed">{toast.message}</p>
          {toast.isDemo && (
            <span className="inline-block mt-1.5 px-2 py-0.5 text-[10px] uppercase tracking-wider font-semibold bg-forest-900/10 text-forest-900 rounded">
              Demo Simulation • Stored in Browser
            </span>
          )}
        </div>
        <button
          onClick={onClose}
          className="text-charcoal-muted hover:text-charcoal p-1 rounded-lg hover:bg-sage/20 transition-colors"
          aria-label="Close notification"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
