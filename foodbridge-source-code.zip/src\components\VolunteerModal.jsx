import React, { useState } from 'react';
import Modal from './Modal';
import { Bike, Shield, HeartHandshake, Sparkles } from 'lucide-react';

export default function VolunteerModal({ isOpen, onClose, onSubmitSuccess }) {
  const initialForm = {
    fullName: '',
    email: '',
    phone: '',
    borough: 'Downtown & Central',
    vehicle: 'Bicycle / E-Bike',
    availability: 'Weekday Evenings (6 PM - 10 PM)',
    hasThermalBag: true,
    experienceNotes: ''
  };

  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.fullName.trim()) newErrors.fullName = 'Full name is required';
    if (!formData.phone.trim()) newErrors.phone = 'Phone is required for dispatch SMS';
    if (!formData.email.trim() || !formData.email.includes('@')) newErrors.email = 'Valid email is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      onSubmitSuccess(formData);
      setIsSubmitting(false);
      setFormData(initialForm);
      onClose();
    }, 400);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Join the Community Courier Squad"
      subtitle="Pedal, drive, or walk to deliver hot, untouched meals from kitchens to shelters in your neighborhood."
    >
      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Full Legal Name *
            </label>
            <input
              type="text"
              placeholder="e.g. Sarah Jenkins"
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.fullName ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.fullName && <p className="text-xs text-red-600 mt-1">{errors.fullName}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Mobile Phone *
            </label>
            <input
              type="tel"
              placeholder="e.g. (555) 819-2044"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.phone ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.phone && <p className="text-xs text-red-600 mt-1">{errors.phone}</p>}
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-forest-900 mb-1">
              Email Address *
            </label>
            <input
              type="email"
              placeholder="sarah.jenkins@example.org"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-lg border text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900 ${
                errors.email ? 'border-red-500' : 'border-sage/50'
              }`}
            />
            {errors.email && <p className="text-xs text-red-600 mt-1">{errors.email}</p>}
          </div>
        </div>

        {/* Mobility and Neighborhood */}
        <div className="bg-ivory-light p-4 rounded-xl border border-sage/40 space-y-4">
          <label className="block text-xs font-bold uppercase tracking-wider text-forest-900">
            Logistics & Vehicle Preferences
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-forest-900 mb-1">
                Primary Mode of Transit
              </label>
              <select
                value={formData.vehicle}
                onChange={(e) => setFormData({ ...formData, vehicle: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-sage/50 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900"
              >
                <option>Bicycle / E-Bike (Preferred for urban core)</option>
                <option>Car / Hatchback (Ideal for catering trays)</option>
                <option>Cargo Van / SUV (For large banquet pallets)</option>
                <option>Motorcycle / Scooter</option>
                <option>Walking (Hyperlocal within 1 km)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-forest-900 mb-1">
                Primary Service Neighborhood
              </label>
              <select
                value={formData.borough}
                onChange={(e) => setFormData({ ...formData, borough: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-sage/50 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900"
              >
                <option>Downtown & Central Business District</option>
                <option>Eastside & Arts District</option>
                <option>West End & University Quarter</option>
                <option>North Suburbs & Tech Corridor</option>
                <option>South Valley Industrial District</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-forest-900 mb-1">
                Preferred Shift Availability
              </label>
              <select
                value={formData.availability}
                onChange={(e) => setFormData({ ...formData, availability: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-sage/50 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-900"
              >
                <option>Weekday Evenings (6:00 PM - 10:30 PM closing surge)</option>
                <option>Weekday Lunch Hour (1:00 PM - 3:00 PM bakery runs)</option>
                <option>Weekends (Saturday & Sunday all day)</option>
                <option>On-Call Emergency Squad (App notification ping)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center space-x-3 pt-1">
            <input
              type="checkbox"
              id="thermalBag"
              checked={formData.hasThermalBag}
              onChange={(e) => setFormData({ ...formData, hasThermalBag: e.target.checked })}
              className="w-4 h-4 text-forest-900 rounded border-sage/60 focus:ring-forest-900"
            />
            <label htmlFor="thermalBag" className="text-xs text-charcoal leading-tight">
              I have (or can obtain) an insulated thermal carrier bag for temperature-safe transport.
            </label>
          </div>
        </div>

        {/* Demo Simulation Alert */}
        <div className="bg-gold-brand/15 border border-gold-brand/40 rounded-xl p-3.5 flex items-start space-x-3 text-xs text-charcoal">
          <Sparkles className="w-4 h-4 text-gold-dark flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-forest-900">Prototype Demonstration</p>
            <p className="text-charcoal-muted mt-0.5">
              Your volunteer profile is stored in your local browser sandbox to demonstrate platform stats and dispatch capability.
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end space-x-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl border border-sage text-sm font-medium text-charcoal hover:bg-sage/20 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-6 py-2.5 rounded-xl bg-forest-900 hover:bg-forest-800 text-ivory text-sm font-medium shadow-md hover:shadow-lg transition-all flex items-center space-x-2"
          >
            <Bike className="w-4 h-4 text-gold-brand" />
            <span>{isSubmitting ? 'Registering...' : 'Complete Volunteer Registration'}</span>
          </button>
        </div>
      </form>
    </Modal>
  );
}
