// Initial illustrative data for FoodBridge

export const INITIAL_STATS = {
  mealsRescued: 142850,
  co2AvertedKg: 89400,
  activeNgos: 420,
  registeredDonors: 1180,
  activeVolunteers: 2340,
  deliveriesToday: 68
};

export const INITIAL_RESCUES = [
  {
    id: 'rescue-001',
    donorName: 'The Grand Heritage Hotel & Suites',
    donorType: 'Hotel & Hospitality',
    foodItem: 'Artisanal Breads, Roasted Medleys & Buffet Entrées',
    quantity: '75 kg (~150 meals)',
    freshnessWindow: 'Safe until 02:00 AM',
    recipientNgo: 'St. Jude Community Kitchen',
    status: 'Delivered',
    timestamp: '18 minutes ago',
    location: 'Downtown North Quarter',
    category: 'Cooked Entrées'
  },
  {
    id: 'rescue-002',
    donorName: 'Trattoria Bella Cucina',
    donorType: 'Fine Dining Restaurant',
    foodItem: 'Freshly Baked Herb Focaccia & Vegetable Risotto',
    quantity: '34 kg (~70 meals)',
    freshnessWindow: 'Safe until 11:30 PM',
    recipientNgo: 'Hope Haven Shelter for Families',
    status: 'In Transit',
    courier: 'Marcus Chen (Volunteer Courier #412)',
    timestamp: '35 minutes ago',
    location: 'Old Town Square',
    category: 'Bakery & Prepared'
  },
  {
    id: 'rescue-003',
    donorName: 'GreenLeaf Organic Supermarket',
    donorType: 'Grocery & Produce',
    foodItem: 'Surplus Seasonal Fruits, Greens & Dairy Cartons',
    quantity: '110 kg (~220 portions)',
    freshnessWindow: 'Best before tomorrow noon',
    recipientNgo: 'Eastside Youth Empowerment Center',
    status: 'Delivered',
    timestamp: '1 hour ago',
    location: 'Metro East District',
    category: 'Fresh Produce'
  },
  {
    id: 'rescue-004',
    donorName: 'Metropolitan Convention Hall',
    donorType: 'Event & Catering',
    foodItem: 'Sealed Gourmet Salads, Quiches & Wraps',
    quantity: '90 kg (~180 meals)',
    freshnessWindow: 'Safe until 03:00 AM',
    recipientNgo: 'Beacon Hill Homeless Outreach',
    status: 'Matching NGO',
    timestamp: '2 hours ago',
    location: 'Financial District',
    category: 'Prepared Meals'
  },
  {
    id: 'rescue-005',
    donorName: 'Pâtisserie Laurent',
    donorType: 'Artisanal Bakery',
    foodItem: 'Brioche Loaves, Baguettes & Whole Wheat Boules',
    quantity: '28 kg (~55 portions)',
    freshnessWindow: 'Best fresh next 12 hrs',
    recipientNgo: 'Grace Senior Living Center',
    status: 'Delivered',
    timestamp: '3 hours ago',
    location: 'Westside Promenade',
    category: 'Bakery'
  }
];

export const HOW_IT_WORKS_STEPS = [
  {
    number: '01',
    title: 'Share',
    subtitle: '60 Seconds to List Surplus',
    description: 'Commercial kitchens, caterers, or households list surplus food with portion counts, dietary tags, safe consumption windows, and pickup instructions.',
    accent: 'From Kitchen to Cloud',
    icon: 'PackagePlus'
  },
  {
    number: '02',
    title: 'Connect',
    subtitle: 'Intelligent Real-Time Match',
    description: 'Our routing algorithm instantly matches the surplus with verified nearby NGOs based on immediate capacity, dietary requirements, and cold-storage capability.',
    accent: 'Zero Algorithmic Delay',
    icon: 'Network'
  },
  {
    number: '03',
    title: 'Coordinate',
    subtitle: 'Vetted Couriers & Volunteers',
    description: 'Nearby background-checked volunteers and logistics partners receive turn-by-turn routing with food safety transport protocols (HACCP thermal containers).',
    accent: 'Safe Cold-Chain Transit',
    icon: 'Navigation'
  },
  {
    number: '04',
    title: 'Deliver',
    subtitle: 'Dignified Community Nourishment',
    description: 'Food arrives fresh at community kitchens, shelters, or distribution centers. The impact ledger updates automatically with verified photo handoff.',
    accent: 'Verified Impact Ledger',
    icon: 'HeartHandshake'
  }
];

export const CORE_FEATURES = [
  {
    id: 'feature-1',
    title: 'On-Demand & Scheduled Food Rescue',
    description: 'List spontaneous banquet surplus in 60 seconds or schedule automated recurring pickups for nightly restaurant closures.',
    highlight: 'HACCP Safety Verification',
    badge: 'Donor Operations'
  },
  {
    id: 'feature-2',
    title: 'Vetted NGO Partner Network',
    description: 'Every NGO partner undergoes rigorous 5-point verification, including hygiene certificates, food handling protocols, and distribution transparency.',
    highlight: '100% Vetted Non-Profits',
    badge: 'Community Security'
  },
  {
    id: 'feature-3',
    title: 'Hyperlocal Pickup Coordination',
    description: 'Smart dispatch connects donors to the nearest volunteer or electric cargo bike courier within a 4-kilometer radius for sub-30 minute rescues.',
    highlight: '< 30 Min Response Time',
    badge: 'Smart Logistics'
  },
  {
    id: 'feature-4',
    title: 'Freshness & Thermal Window Tracking',
    description: 'Real-time countdown clocks track preparation timestamps, ambient temperature logs, and maximum safe consumption windows.',
    highlight: 'Zero Compromise on Quality',
    badge: 'Food Safety'
  },
  {
    id: 'feature-5',
    title: 'Volunteer Squads & Fleet Management',
    description: 'Flexible shifts for cyclists, drivers, and walking escorts. Gamified impact levels, volunteer badges, and verified service hour certificates.',
    highlight: 'Community Powered',
    badge: 'Civic Action'
  },
  {
    id: 'feature-6',
    title: 'Automated ESG & Tax Ledger',
    description: 'Generate institutional ESG impact reports detailing meals salvaged, methane avoided, and charitable contribution receipts compliant with tax laws.',
    highlight: 'Audit-Ready Reporting',
    badge: 'Institutional Impact'
  }
];

export const STORY_MILESTONES = [
  {
    time: '21:15',
    title: 'The Banquet Concludes',
    actor: 'Chef Marco Valenti',
    organization: 'Trattoria Bella Cucina',
    description: 'A 180-guest corporate dinner concludes. The kitchen has 40 perfectly preserved portions of artisanal vegetable lasagna and warm rustic sourdough.',
    insight: 'Conventionally, strict safety protocols might lead to landfill disposal. FoodBridge offers a safe, legal, and rapid alternative.',
    icon: 'ChefHat'
  },
  {
    time: '21:22',
    title: 'FoodBridge Listing Created',
    actor: 'Sous Chef Elena',
    organization: 'Digital Kitchen Dispatch',
    description: 'Elena opens the FoodBridge app, snaps a photo, sets the thermal condition (warm holding > 65°C), and submits the listing in 48 seconds.',
    insight: 'Food safety parameters are logged immediately, generating an automated chain-of-custody token.',
    icon: 'Smartphone'
  },
  {
    time: '21:30',
    title: 'Volunteer Courier Dispatched',
    actor: 'Marcus Chen',
    organization: 'Neighborhood Volunteer Squad',
    description: 'Marcus, cycling nearby with an insulated thermal delivery bag, accepts the pickup ping. He arrives at Trattoria Bella within 8 minutes.',
    insight: 'Decentralized local volunteers eliminate expensive overhead and navigate urban congestion seamlessly.',
    icon: 'Bike'
  },
  {
    time: '21:55',
    title: 'Warm Plates at Hope Haven',
    actor: 'Sister Angela & Team',
    organization: 'Hope Haven Community Kitchen',
    description: 'The meals arrive at Hope Haven shelter 3.2 miles away. By 22:10, 40 individuals and families receive a nutritious, chef-crafted dinner.',
    insight: 'Every single meal retains its dignity, fresh flavor, and nutritional vitality.',
    icon: 'HeartHandshake'
  }
];

export const TESTIMONIALS = [
  {
    quote: "FoodBridge turned our closing routine from a moment of guilt into our kitchen team's proudest daily habit. We've redirected over 4,200 kg of gourmet food this year alone.",
    name: "Chef Marco Valenti",
    role: "Executive Chef & Owner",
    org: "Trattoria Bella",
    image: "https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=300&q=80"
  },
  {
    quote: "Our shelter budget is consistently stretched. Receiving hot, restaurant-grade meals within 45 minutes of preparation allows us to reallocate scarce funds toward counseling and job placement.",
    name: "Dr. Evelyn Vance",
    role: "Director of Outreach",
    org: "Hope Haven Shelter",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80"
  },
  {
    quote: "I do three deliveries a week on my cargo bike after work. Knowing that a 20-minute pedal literally puts hot food on a child's dinner table gives purpose to my daily commute.",
    name: "Marcus Chen",
    role: "Active Volunteer Courier",
    org: "Central Borough Chapter",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80"
  }
];
