import { INITIAL_STATS, INITIAL_RESCUES } from '../data/mockData';

const STORAGE_KEYS = {
  DONATIONS: 'foodbridge_donations',
  VOLUNTEERS: 'foodbridge_volunteers',
  NGOS: 'foodbridge_ngos',
  RESCUES: 'foodbridge_rescues',
  STATS: 'foodbridge_stats',
};

// Safe JSON parser
function safeGet(key, fallback) {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch (e) {
    console.warn(`Error reading ${key} from localStorage:`, e);
    return fallback;
  }
}

function safeSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn(`Error writing ${key} to localStorage:`, e);
  }
}

export function getStats() {
  return safeGet(STORAGE_KEYS.STATS, INITIAL_STATS);
}

export function getRescues() {
  return safeGet(STORAGE_KEYS.RESCUES, INITIAL_RESCUES);
}

export function getDonations() {
  return safeGet(STORAGE_KEYS.DONATIONS, []);
}

export function getVolunteers() {
  return safeGet(STORAGE_KEYS.VOLUNTEERS, []);
}

export function getNgos() {
  return safeGet(STORAGE_KEYS.NGOS, []);
}

export function addDonation(donationData) {
  const currentDonations = getDonations();
  const newDonation = {
    ...donationData,
    id: 'don-' + Date.now(),
    createdAt: new Date().toISOString(),
    status: 'Matching Verified NGO'
  };
  
  const updatedDonations = [newDonation, ...currentDonations];
  safeSet(STORAGE_KEYS.DONATIONS, updatedDonations);

  // Also prepend to live rescues feed so user sees their submission in the live dashboard
  const currentRescues = getRescues();
  const mealsCount = parseInt(donationData.estimatedMeals, 10) || Math.round((parseFloat(donationData.quantityKg) || 10) * 2);
  
  const newRescueFeedItem = {
    id: 'rescue-' + Date.now(),
    donorName: donationData.donorName || 'Community Food Donor',
    donorType: donationData.donorType || 'Commercial Donor',
    foodItem: donationData.foodDescription || 'Prepared Meals & Fresh Food',
    quantity: `${donationData.quantityKg || '25'} kg (~${mealsCount} meals)`,
    freshnessWindow: `Pickup window: ${donationData.pickupWindow || 'Immediate'}`,
    recipientNgo: 'Awaiting Automated Dispatch',
    status: 'Dispatch Pending',
    timestamp: 'Just now (Demo Submission)',
    location: donationData.location || 'Borough Metro Area',
    category: donationData.foodType || 'Nutritious Meals',
    isUserDemoSubmission: true
  };

  const updatedRescues = [newRescueFeedItem, ...currentRescues];
  safeSet(STORAGE_KEYS.RESCUES, updatedRescues);

  // Increment simulated stats
  const currentStats = getStats();
  const updatedStats = {
    ...currentStats,
    mealsRescued: currentStats.mealsRescued + mealsCount,
    co2AvertedKg: currentStats.co2AvertedKg + Math.round(mealsCount * 0.6),
    deliveriesToday: currentStats.deliveriesToday + 1
  };
  safeSet(STORAGE_KEYS.STATS, updatedStats);

  return { newDonation, updatedStats, updatedRescues };
}

export function addVolunteer(volunteerData) {
  const currentVolunteers = getVolunteers();
  const newVolunteer = {
    ...volunteerData,
    id: 'vol-' + Date.now(),
    createdAt: new Date().toISOString(),
    status: 'Verified Candidate (Simulation)'
  };
  const updated = [newVolunteer, ...currentVolunteers];
  safeSet(STORAGE_KEYS.VOLUNTEERS, updated);

  const currentStats = getStats();
  const updatedStats = {
    ...currentStats,
    activeVolunteers: currentStats.activeVolunteers + 1
  };
  safeSet(STORAGE_KEYS.STATS, updatedStats);

  return newVolunteer;
}

export function addNgo(ngoData) {
  const currentNgos = getNgos();
  const newNgo = {
    ...ngoData,
    id: 'ngo-' + Date.now(),
    createdAt: new Date().toISOString(),
    status: 'Under Verification Review (Simulation)'
  };
  const updated = [newNgo, ...currentNgos];
  safeSet(STORAGE_KEYS.NGOS, updated);

  const currentStats = getStats();
  const updatedStats = {
    ...currentStats,
    activeNgos: currentStats.activeNgos + 1
  };
  safeSet(STORAGE_KEYS.STATS, updatedStats);

  return newNgo;
}

export function resetDemoData() {
  localStorage.removeItem(STORAGE_KEYS.DONATIONS);
  localStorage.removeItem(STORAGE_KEYS.VOLUNTEERS);
  localStorage.removeItem(STORAGE_KEYS.NGOS);
  safeSet(STORAGE_KEYS.RESCUES, INITIAL_RESCUES);
  safeSet(STORAGE_KEYS.STATS, INITIAL_STATS);
  return {
    rescues: INITIAL_RESCUES,
    stats: INITIAL_STATS,
    donations: [],
    volunteers: [],
    ngos: []
  };
}
