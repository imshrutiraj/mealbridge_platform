/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        forest: {
          900: '#123B2A', // Deep Forest Green
          800: '#1a4e38',
          700: '#245B40', // Emerald
          600: '#2f7453',
        },
        emerald: {
          brand: '#245B40',
        },
        ivory: {
          DEFAULT: '#F7F4EB', // Warm Ivory
          light: '#FCFAF5',
          dark: '#EFE9DA',
        },
        sage: {
          DEFAULT: '#A9BDA7', // Muted Sage
          light: '#C8D6C7',
          dark: '#7D957B',
        },
        gold: {
          brand: '#D9A45B', // Champagne Gold
          light: '#E6BA79',
          dark: '#B88239',
        },
        charcoal: {
          DEFAULT: '#292E29', // Soft Charcoal
          light: '#424842',
          muted: '#626A62',
        }
      },
      fontFamily: {
        serif: ['"Playfair Display"', 'Georgia', 'serif'],
        sans: ['"DM Sans"', 'system-ui', '-apple-system', 'sans-serif'],
      },
      boxShadow: {
        'soft-editorial': '0 20px 40px -15px rgba(18, 59, 42, 0.08), 0 0 1px 1px rgba(18, 59, 42, 0.04)',
        'premium': '0 30px 60px -20px rgba(18, 59, 42, 0.15)',
        'gold-glow': '0 10px 25px -5px rgba(217, 164, 91, 0.3)',
      }
    },
  },
  plugins: [],
}
